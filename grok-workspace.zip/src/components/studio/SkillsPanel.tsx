import { t } from "@/lib/studio/i18n";
import { SKILLS } from "@/lib/studio/skills";
import { useStudio } from "@/lib/studio/store";

export function SkillsPanel() {
  const lang = useStudio((s) => s.lang);
  const skills = useStudio((s) => s.skills);
  const toggle = useStudio((s) => s.toggleSkill);
  return (
    <section className="flex flex-col gap-3">
      <div className="rounded-2xl border border-border bg-surface p-4">
        <h1 className="text-lg font-semibold">{t(lang, "skills")}</h1>
        <p className="mt-1 text-sm leading-6 text-muted">
          {lang === "hi"
            ? "ये टॉगल पाइपलाइन पढ़ती है। बंद स्किल चलती नहीं — सिर्फ सजावट नहीं।"
            : "The pipeline reads these toggles. Off means that step does not run."}
        </p>
      </div>
      {(["pipeline", "product"] as const).map((group) => (
        <div key={group} className="rounded-2xl border border-border bg-surface p-4">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted">{group}</h2>
          <ul className="mt-3 flex flex-col gap-2">
            {SKILLS.filter((s) => s.group === group).map((skill) => {
              const on = skills[skill.id] !== false;
              return (
                <li key={skill.id} className="flex items-center gap-3 rounded-xl bg-surface-2 px-3 py-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold">{lang === "hi" ? skill.hi : skill.en}</p>
                    <p className="text-xs leading-5 text-muted">{lang === "hi" ? skill.detailHi : skill.detailEn}</p>
                  </div>
                  <button
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggle(skill.id, !on)}
                    className={`h-11 shrink-0 rounded-xl px-3 text-sm font-semibold ${on ? "bg-accent text-accent-ink" : "border border-border text-muted"}`}
                  >
                    {on ? (lang === "hi" ? "चालू" : "On") : lang === "hi" ? "बंद" : "Off"}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </section>
  );
}
