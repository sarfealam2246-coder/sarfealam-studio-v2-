import { Check } from "lucide-react";
import { useState } from "react";
import { StatusStrip } from "@/components/studio/chrome";
import { t } from "@/lib/studio/i18n";
import { buildChips, deriveChecks, mapFooter } from "@/lib/studio/map";
import { skillLabel } from "@/lib/studio/skills";
import { useStudio } from "@/lib/studio/store";
import type { Job } from "@/lib/studio/types";

const STAGE_KEYS = ["shell", "screens", "hero", "controls", "test"] as const;

export function BuildPanel({
  onAssemble,
  onDemo,
  onChange,
  onRollback,
  onResume,
}: {
  onAssemble: (prompt: string) => void;
  onDemo: (prompt: string) => void;
  onChange: (text: string) => void;
  onRollback: () => void;
  onResume: () => void;
}) {
  const lang = useStudio((s) => s.lang);
  const view = useStudio((s) => s.view);
  const job = useStudio((s) => s.jobs.find((j) => j.id === s.activeJobId) ?? null);
  const secrets = useStudio((s) => s.secrets);
  const [prompt, setPrompt] = useState("");
  const showFactory = view === "factory" && job && job.status !== "cancelled";
  return (
    <section className="flex flex-col gap-3">
      <StatusStrip />
      {showFactory && job ? (
        <Factory job={job} onChange={onChange} onRollback={onRollback} />
      ) : (
        <div className="rounded-2xl border border-border bg-surface p-4">
          <h1 className="text-lg font-semibold">{t(lang, "build")}</h1>
          <p className="mt-1 text-sm leading-6 text-muted">
            {lang === "hi"
              ? "प्रॉम्प्ट → असेंबली → टेस्ट → ठीक → वॉल्ट में लिंक। बिना कुंजी के APK तैयार नहीं दिखेगा।"
              : "Prompt → assembly → test → OK → links in Vault. With no key, nothing is marked APK ready."}
          </p>
          <label className="mt-4 block text-sm font-medium" htmlFor="build-prompt">
            Prompt
          </label>
          <textarea
            id="build-prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={t(lang, "promptPh")}
            rows={4}
            className="mt-2 w-full rounded-xl border border-border bg-surface-2 px-3 py-3 text-sm"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className="h-12 rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink" onClick={() => onAssemble(prompt)}>
              {t(lang, "assemble")}
            </button>
            {secrets.keys.length === 0 ? (
              <button type="button" className="h-12 rounded-xl border border-border px-4 text-sm font-semibold" onClick={() => onDemo(prompt)}>
                {t(lang, "demo")}
              </button>
            ) : null}
          </div>
          {job && (job.status === "assembling" || job.status === "testing" || job.status === "exporting" || job.status === "ready") ? (
            <button type="button" className="mt-4 h-12 w-full rounded-xl bg-surface-2 text-sm font-semibold" onClick={onResume}>
              {job.title} · {job.demo ? "demo" : job.status} · {t(lang, "resume")}
            </button>
          ) : null}
        </div>
      )}
    </section>
  );
}

function Factory({
  job,
  onChange,
  onRollback,
}: {
  job: Job;
  onChange: (text: string) => void;
  onRollback: () => void;
}) {
  const lang = useStudio((s) => s.lang);
  const secrets = useStudio((s) => s.secrets);
  const health = useStudio((s) => s.health);
  const skills = useStudio((s) => s.skills);
  const logTest = useStudio((s) => s.logTest);
  const [change, setChange] = useState("");
  const [screen, setScreen] = useState(0);
  const [car, setCar] = useState({ x: 50, speed: 0 });
  const mapOn = skills["system-map"] !== false;
  const chips = buildChips({
    secrets,
    health,
    systemMapOn: mapOn,
    selfHealOn: skills["self-heal"] !== false,
    researchOn: skills["research-bot"] !== false,
    job,
    secretsHealthOn: skills["secrets-health"] !== false,
  });
  const footer = mapFooter({
    job,
    derived: deriveChecks(secrets, health, skills["secrets-health"] !== false),
    exportingNeedsGithub: job.status === "exporting" || job.status === "ready",
  });
  const spec = job.spec;
  const screens = spec?.screens?.length ? spec.screens : [{ name: "…", blurb: job.prompt }];
  const activeScreen = screens[Math.min(screen, screens.length - 1)];
  const testOn = job.stage >= 5 && (job.status === "testing" || job.status === "ready");
  const showWallet = job.matchedSkills.includes("wallet");
  const showSearch = job.matchedSkills.includes("search");
  const showVip = job.matchedSkills.includes("vip");
  const showNav = job.matchedSkills.includes("bottom-nav") || screens.length > 1;
  const game = job.kind === "game" || job.matchedSkills.includes("game-controls");

  function nudge(dir: number) {
    if (!testOn) return;
    setCar((c) => ({ ...c, x: Math.min(88, Math.max(12, c.x + dir)) }));
    logTest(dir < 0 ? "steer-left" : "steer-right");
  }

  return (
    <div className="grid gap-3 lg:grid-cols-2">
      <article className="rounded-2xl border border-border bg-surface p-4">
        <header className="flex items-baseline justify-between gap-2">
          <h2 className="text-base font-semibold">{lang === "hi" ? "प्रोडक्ट असेंबली" : "Product assembly"}</h2>
          <span className="font-mono text-xs text-muted">{job.engine === "godot" ? "Godot 4" : "Flutter"}</span>
        </header>
        {job.demo ? <p className="mt-2 rounded-xl bg-surface-2 px-3 py-2 text-sm text-accent">{t(lang, "demoBanner")}</p> : null}
        <ol className="mt-3 grid grid-cols-5 gap-1">
          {STAGE_KEYS.map((key, index) => {
            const n = index + 1;
            const done = job.stage > n || (job.stage === n && (job.status === "testing" || job.status === "ready"));
            const active = job.status === "assembling" && job.stage === n;
            return (
              <li key={key} className={`rounded-lg border px-1 py-2 text-center ${active ? "border-accent" : "border-border"} ${done ? "text-accent" : "text-muted"}`}>
                <span className="block font-mono text-xs">{done ? <Check className="mx-auto size-3.5" /> : n}</span>
                <span className="mt-1 block text-xs leading-4">{t(lang, key)}</span>
              </li>
            );
          })}
        </ol>
        <div className="mx-auto mt-4 w-full max-w-sm rounded-2xl border border-border bg-bg p-3">
          <div className="rounded-xl border border-border bg-surface p-3">
            <p className="text-xs text-muted">{job.stage >= 1 ? (spec?.title || job.title) : "…"}</p>
            {job.stage >= 3 ? <p className="mt-2 text-base font-semibold">{spec?.hero || spec?.title}</p> : <div className="mt-3 h-6 rounded bg-surface-2" />}
            {job.stage >= 2 ? (
              <>
                {showSearch && testOn ? (
                  <input className="mt-3 h-10 w-full rounded-lg border border-border bg-surface-2 px-2 text-sm" placeholder={t(lang, "search")} onChange={() => logTest("search")} />
                ) : null}
                <p className="mt-3 text-sm leading-6">{activeScreen?.blurb}</p>
                {showWallet ? <p className="mt-2 rounded-lg bg-surface-2 px-3 py-2 text-sm">{lang === "hi" ? "बैलेंस · असली राशि नहीं" : "Balance · not real funds"}</p> : null}
                {showVip ? <p className="mt-2 text-sm text-muted">VIP · {job.vipNote || (lang === "hi" ? "प्लान लॉक" : "plan locked")}</p> : null}
                {job.matchedSkills.includes("card-table") ? <p className="mt-2 font-mono text-sm">A♠ K♥ 7♦</p> : null}
              </>
            ) : (
              <p className="mt-3 text-sm text-muted">{job.prompt}</p>
            )}
            {game && job.stage >= 2 ? (
              <div className="relative mt-3 h-28 overflow-hidden rounded-xl bg-surface-2">
                <span className="absolute bottom-3 size-8 rounded-md bg-accent" style={{ left: `${car.x}%`, transform: "translateX(-50%)" }} />
              </div>
            ) : null}
            {job.stage >= 4 && game ? (
              <div className="mt-3 grid grid-cols-4 gap-2">
                <TestBtn label="L" disabled={!testOn} onClick={() => nudge(-12)} />
                <TestBtn label={lang === "hi" ? "गैस" : "Gas"} disabled={!testOn} onClick={() => { if (!testOn) return; setCar((c) => ({ ...c, speed: c.speed + 1 })); logTest("gas"); }} />
                <TestBtn label={lang === "hi" ? "ब्रेक" : "Brake"} disabled={!testOn} onClick={() => { if (!testOn) return; setCar((c) => ({ ...c, speed: 0 })); logTest("brake"); }} />
                <TestBtn label="R" disabled={!testOn} onClick={() => nudge(12)} />
              </div>
            ) : null}
            {showNav && job.stage >= 2 ? (
              <div className="mt-3 flex gap-1">
                {screens.map((item, i) => (
                  <button
                    key={item.name + i}
                    type="button"
                    disabled={!testOn}
                    className={`h-10 flex-1 rounded-lg text-xs font-semibold disabled:opacity-50 ${i === screen ? "bg-accent text-accent-ink" : "bg-surface-2"}`}
                    onClick={() => {
                      setScreen(i);
                      logTest(`tab:${item.name}`);
                    }}
                  >
                    {item.name}
                  </button>
                ))}
              </div>
            ) : null}
          </div>
        </div>
        {job.visionNote ? <p className="mt-3 text-sm leading-6 text-muted">{job.visionNote}</p> : null}
        {job.error ? <p className="mt-3 text-sm">{job.error}</p> : null}
        {job.skippedSkills.length > 0 ? (
          <ul className="mt-3 text-xs text-muted">
            {job.skippedSkills.map((s) => (
              <li key={s.id}>
                {skillLabel(s.id, lang)} · {s.reason}
              </li>
            ))}
          </ul>
        ) : null}
        {testOn && !job.demo ? (
          <form
            className="mt-3 flex flex-col gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!change.trim()) return;
              onChange(change);
              setChange("");
            }}
          >
            <input value={change} onChange={(e) => setChange(e.target.value)} placeholder={t(lang, "changePh")} className="h-12 rounded-xl border border-border bg-surface-2 px-3 text-sm" />
            <div className="flex gap-2">
              <button type="submit" className="h-11 flex-1 rounded-xl bg-surface-2 text-sm font-semibold">{t(lang, "applyChange")}</button>
              <button type="button" className="h-11 flex-1 rounded-xl border border-border text-sm font-semibold" onClick={onRollback}>{t(lang, "rollback")}</button>
            </div>
          </form>
        ) : null}
      </article>
      <article className="rounded-2xl border border-border bg-surface p-4">
        <h2 className="text-base font-semibold">{lang === "hi" ? "सिस्टम मैप" : "System map"}</h2>
        {!mapOn ? (
          <p className="mt-3 text-sm text-muted">{lang === "hi" ? "सिस्टम मैप स्किल बंद है — टीम नेविगेशन नहीं चल रहा।" : "System map skill is off — team navigation is not running."}</p>
        ) : (
          <div className="relative mt-4">
            <svg className="pointer-events-none absolute top-2 bottom-2 left-4 w-4" aria-hidden="true">
              <line x1="8" y1="0" x2="8" y2="100%" className="map-flow stroke-accent" strokeWidth="2" />
            </svg>
            <ol className="flex flex-col gap-2 pl-8">
              {chips.chips.map((chip) => (
                <li key={chip.id} className={`rounded-xl border px-3 py-2 ${chip.state === "active" ? "border-accent" : "border-border"} ${chip.state === "muted" ? "opacity-60" : ""}`}>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold">{chip.label}</p>
                    {chip.state === "done" ? <Check className="size-4 text-accent" /> : null}
                  </div>
                  <p className="font-mono text-xs text-muted">{chip.state === "muted" ? chip.reason : chip.caption}</p>
                </li>
              ))}
            </ol>
          </div>
        )}
        <p className="mt-4 font-mono text-xs text-muted">{footer}</p>
      </article>
    </div>
  );
}

function TestBtn({ label, onClick, disabled }: { label: string; onClick: () => void; disabled: boolean }) {
  return (
    <button type="button" disabled={disabled} onClick={onClick} className="h-11 rounded-lg bg-surface-2 text-xs font-semibold disabled:opacity-40">
      {label}
    </button>
  );
}
