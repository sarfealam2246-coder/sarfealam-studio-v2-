import { t } from "@/lib/studio/i18n";
import { useStudio } from "@/lib/studio/store";

export function AdminPanel({ buildId, onPoll }: { buildId: string; onPoll: () => void }) {
  const lang = useStudio((s) => s.lang);
  const jobs = useStudio((s) => s.jobs);
  const activeId = useStudio((s) => s.activeJobId);
  const focusJob = useStudio((s) => s.focusJob);
  const patchJob = useStudio((s) => s.patchJob);
  const selected = jobs.find((j) => j.id === (buildId || activeId)) ?? jobs[0] ?? null;
  return (
    <section className="flex flex-col gap-3">
      <div className="rounded-2xl border border-border bg-surface p-4">
        <h1 className="text-lg font-semibold">{t(lang, "admin")}</h1>
        <p className="mt-1 text-sm text-muted">{t(lang, "localDraft")}</p>
        {jobs.length > 0 ? (
          <label className="mt-3 block text-sm">
            {lang === "hi" ? "बिल्ड" : "Build"}
            <select
              className="mt-1 h-12 w-full rounded-xl border border-border bg-surface-2 px-3"
              value={selected?.id ?? ""}
              onChange={(e) => focusJob(e.target.value)}
            >
              {jobs.map((job) => (
                <option key={job.id} value={job.id}>
                  {job.title}
                </option>
              ))}
            </select>
          </label>
        ) : (
          <p className="mt-3 text-sm">{lang === "hi" ? "पहले एक बिल्ड चुनने लायक कुछ नहीं है।" : "Nothing to administer yet."}</p>
        )}
      </div>
      {selected ? (
        <div className="rounded-2xl border border-border bg-surface p-4">
          <p className="font-mono text-xs text-muted">{selected.demo ? "demo" : selected.status}</p>
          <label className="mt-4 flex items-center justify-between gap-3 text-sm">
            <span>{t(lang, "banner")}</span>
            <button
              type="button"
              aria-pressed={selected.bannerOn}
              onClick={() => patchJob(selected.id, { bannerOn: !selected.bannerOn })}
              className={`h-11 rounded-xl px-4 font-semibold ${selected.bannerOn ? "bg-accent text-accent-ink" : "bg-surface-2"}`}
            >
              {selected.bannerOn ? (lang === "hi" ? "चालू" : "On") : lang === "hi" ? "बंद" : "Off"}
            </button>
          </label>
          {selected.bannerOn ? <p className="mt-2 rounded-xl bg-accent px-3 py-2 text-sm font-semibold text-accent-ink">{selected.title}</p> : null}
          <label className="mt-4 block text-sm" htmlFor="note-draft">
            {t(lang, "notify")}
            <textarea
              id="note-draft"
              value={selected.notification}
              onChange={(e) => patchJob(selected.id, { notification: e.target.value })}
              rows={3}
              className="mt-1 w-full rounded-xl border border-border bg-surface-2 px-3 py-2"
              placeholder={lang === "hi" ? "लोकल ड्राफ्ट — भेजा नहीं गया" : "Local draft — not sent"}
            />
          </label>
          <label className="mt-3 block text-sm" htmlFor="vip-note">
            {t(lang, "vip")}
            <input
              id="vip-note"
              value={selected.vipNote}
              onChange={(e) => patchJob(selected.id, { vipNote: e.target.value })}
              className="mt-1 h-12 w-full rounded-xl border border-border bg-surface-2 px-3"
            />
          </label>
          <div className="mt-4 rounded-xl border border-border bg-bg p-3 text-sm">
            <p className="text-muted">{t(lang, "apk")}</p>
            {selected.apkLink ? (
              <a className="mt-1 block break-all text-accent underline" href={selected.apkLink} target="_blank" rel="noreferrer">
                {selected.apkLink}
              </a>
            ) : (
              <p className="mt-1">{selected.apkDetail || (lang === "hi" ? "APK तैयार नहीं" : "APK not ready")}</p>
            )}
            <p className="mt-3 text-muted">{t(lang, "adminLink")}</p>
            {selected.adminLink ? (
              <a className="mt-1 block break-all text-accent underline" href={selected.adminLink}>
                {selected.adminLink}
              </a>
            ) : (
              <p className="mt-1">{selected.adminDetail || (lang === "hi" ? "एडमिन लिंक नहीं" : "No Admin link")}</p>
            )}
          </div>
          {selected.repoOwner ? (
            <button type="button" className="mt-3 h-11 rounded-xl bg-surface-2 px-4 text-sm font-semibold" onClick={onPoll}>
              {t(lang, "poll")}
            </button>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
