import { useState } from "react";
import { t } from "@/lib/studio/i18n";
import { providerDefaultModel } from "@/lib/studio/routing";
import { uid, useStudio } from "@/lib/studio/store";
import type { ApiKey, ProviderId, Tag } from "@/lib/studio/types";

const PROVIDERS: ProviderId[] = ["gemini", "groq", "openai", "nvidia", "xai", "qwen", "anthropic", "custom"];
const TAGS: Tag[] = ["general", "code", "fast", "vision", "primary", "fallback"];

const EMPTY: ApiKey = {
  id: "",
  label: "",
  provider: "gemini",
  model: providerDefaultModel("gemini"),
  baseUrl: "",
  secret: "",
  tags: ["general"],
};

export function SecretsPanel({ onSaved }: { onSaved: () => void }) {
  const lang = useStudio((s) => s.lang);
  const secrets = useStudio((s) => s.secrets);
  const saveKey = useStudio((s) => s.saveKey);
  const deleteKey = useStudio((s) => s.deleteKey);
  const saveTokens = useStudio((s) => s.saveTokens);
  const saveVoice = useStudio((s) => s.saveVoice);
  const saveStudioFb = useStudio((s) => s.saveStudioFb);
  const saveAppsFb = useStudio((s) => s.saveAppsFb);
  const [draft, setDraft] = useState<ApiKey>(EMPTY);
  const [token1, setToken1] = useState(secrets.token1);
  const [token2, setToken2] = useState(secrets.token2);
  const [voice, setVoice] = useState(secrets.voiceKey);
  const [studioUrl, setStudioUrl] = useState(secrets.studioUrl);
  const [studioKey, setStudioKey] = useState(secrets.studioKey);
  const [appsUrl, setAppsUrl] = useState(secrets.appsUrl);
  const [appsKey, setAppsKey] = useState(secrets.appsKey);
  const [formError, setFormError] = useState("");

  const slots = Math.max(7, secrets.keys.length);

  function commitKey() {
    if (!draft.label.trim() || !draft.secret.trim()) {
      setFormError(lang === "hi" ? "नाम और कुंजी दोनों चाहिए।" : "Name and key are both required.");
      return;
    }
    if (draft.provider === "custom" && !draft.baseUrl.trim().startsWith("https://")) {
      setFormError(lang === "hi" ? "कस्टम बेस URL https होना चाहिए।" : "Custom base URL must start with https://");
      return;
    }
    saveKey({
      ...draft,
      id: draft.id || uid(),
      label: draft.label.trim(),
      model: draft.model.trim() || providerDefaultModel(draft.provider),
      secret: draft.secret.trim(),
    });
    setDraft(EMPTY);
    setFormError("");
    onSaved();
  }

  return (
    <section className="flex flex-col gap-3">
      <div className="rounded-2xl border border-border bg-surface p-4">
        <h1 className="text-lg font-semibold">{t(lang, "secrets")}</h1>
        <p className="mt-1 text-sm leading-6 text-muted">
          {lang === "hi"
            ? "कुंजियाँ इस ब्राउज़र में रहती हैं जब तक आप मिटाएँ नहीं। वे Studio Firebase पर नहीं जातीं। एक General कुंजी बेसिक बिल्ड के लिए काफी है।"
            : "Keys stay in this browser until you delete them. They are not copied to Studio Firebase. One General key is enough for a basic build."}
        </p>
      </div>

      <section className="rounded-2xl border border-border bg-surface p-4">
        <h2 className="text-base font-semibold">{lang === "hi" ? "API कुंजियाँ" : "API keys"}</h2>
        <ul className="mt-3 flex flex-col gap-2">
          {Array.from({ length: slots }, (_, i) => secrets.keys[i] ?? null).map((key, index) =>
            key ? (
              <li key={key.id} className="rounded-xl bg-surface-2 px-3 py-3">
                <p className="text-sm font-semibold">{key.label}</p>
                <p className="font-mono text-xs text-muted">
                  {key.provider} · {key.model} · {key.tags.join(", ") || "untagged"}
                </p>
                <div className="mt-2 flex gap-2">
                  <button type="button" className="h-10 rounded-lg px-3 text-sm font-semibold" onClick={() => setDraft(key)}>
                    {t(lang, "edit")}
                  </button>
                  <button
                    type="button"
                    className="h-10 rounded-lg px-3 text-sm font-semibold text-muted"
                    onClick={() => {
                      deleteKey(key.id);
                      onSaved();
                    }}
                  >
                    {t(lang, "delete")}
                  </button>
                </div>
              </li>
            ) : (
              <li key={`empty-${index}`} className="rounded-xl border border-dashed border-border px-3 py-3 text-sm text-muted">
                {t(lang, "slotEmpty")} {index + 1}
              </li>
            ),
          )}
        </ul>
        <div className="mt-4 grid gap-2">
          <Field label={lang === "hi" ? "नाम" : "Name"} value={draft.label} onChange={(label) => setDraft({ ...draft, label })} placeholder="Qwen Coder" />
          <label className="text-sm">
            Provider
            <select
              className="mt-1 h-12 w-full rounded-xl border border-border bg-bg px-3"
              value={draft.provider}
              onChange={(e) => {
                const provider = e.target.value as ProviderId;
                setDraft({ ...draft, provider, model: providerDefaultModel(provider) });
              }}
            >
              {PROVIDERS.map((id) => (
                <option key={id} value={id}>
                  {id}
                </option>
              ))}
            </select>
          </label>
          <Field label="Model" value={draft.model} onChange={(model) => setDraft({ ...draft, model })} />
          {draft.provider === "custom" ? <Field label="Base URL" value={draft.baseUrl} onChange={(baseUrl) => setDraft({ ...draft, baseUrl })} placeholder="https://example.com/v1" /> : null}
          <Field label={lang === "hi" ? "गुप्त कुंजी" : "Secret"} value={draft.secret} onChange={(secret) => setDraft({ ...draft, secret })} secret />
          <div className="flex flex-wrap gap-2">
            {TAGS.map((tag) => {
              const on = draft.tags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  aria-pressed={on}
                  onClick={() =>
                    setDraft({
                      ...draft,
                      tags: on ? draft.tags.filter((t) => t !== tag) : [...draft.tags, tag],
                    })
                  }
                  className={`h-10 rounded-lg px-3 text-xs font-semibold ${on ? "bg-accent text-accent-ink" : "bg-surface-2 text-muted"}`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
          {formError ? <p className="text-sm">{formError}</p> : null}
          <button type="button" className="h-12 rounded-xl bg-accent text-sm font-semibold text-accent-ink" onClick={commitKey}>
            {t(lang, "save")}
          </button>
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-surface p-4">
        <h2 className="text-base font-semibold">{lang === "hi" ? "टोकन" : "Tokens"}</h2>
        <p className="mt-1 text-xs text-muted">Token1 = GitHub (repo scope). Token2 = reserve, left empty.</p>
        <Field label="Token1 · GitHub" value={token1} onChange={setToken1} secret />
        <Field label="Token2 · Reserve" value={token2} onChange={setToken2} secret />
        <button
          type="button"
          className="mt-3 h-12 rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink"
          onClick={() => {
            saveTokens(token1, token2);
            onSaved();
          }}
        >
          {t(lang, "save")}
        </button>
      </section>

      <section className="rounded-2xl border border-border bg-surface p-4">
        <h2 className="text-base font-semibold">{lang === "hi" ? "वॉइस कुंजी" : "Voice key"}</h2>
        <p className="mt-1 text-xs text-muted">
          {lang === "hi" ? "अलग स्लॉट। लाइव इस ब्राउज़र की पहचान का उपयोग करता है।" : "Separate slot. Live uses this browser’s recognition, not this key."}
        </p>
        <Field label="Voice" value={voice} onChange={setVoice} secret />
        <div className="mt-3 flex gap-2">
          <button type="button" className="h-12 rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink" onClick={() => { saveVoice(voice); onSaved(); }}>
            {t(lang, "save")}
          </button>
          <button type="button" className="h-12 rounded-xl border border-border px-4 text-sm" onClick={() => { setVoice(""); saveVoice(""); onSaved(); }}>
            {t(lang, "delete")}
          </button>
        </div>
      </section>

      <FirebaseBlock
        title={t(lang, "studioFb")}
        hint={lang === "hi" ? "जॉब, भाषा, चरण। API कुंजियाँ नहीं।" : "Jobs, language, stages. Not API keys."}
        url={studioUrl}
        secret={studioKey}
        onUrl={setStudioUrl}
        onSecret={setStudioKey}
        onSave={() => {
          saveStudioFb(studioUrl, studioKey);
          onSaved();
        }}
        onDelete={() => {
          setStudioUrl("");
          setStudioKey("");
          saveStudioFb("", "");
          onSaved();
        }}
      />
      <FirebaseBlock
        title={t(lang, "appsFb")}
        hint={lang === "hi" ? "OK पर लोकल एक्सपोर्ट में जाता है, GitHub पर नहीं।" : "Injected into the local export on OK, not committed to GitHub."}
        url={appsUrl}
        secret={appsKey}
        onUrl={setAppsUrl}
        onSecret={setAppsKey}
        onSave={() => {
          saveAppsFb(appsUrl, appsKey);
          onSaved();
        }}
        onDelete={() => {
          setAppsUrl("");
          setAppsKey("");
          saveAppsFb("", "");
          onSaved();
        }}
      />
    </section>
  );
}

function FirebaseBlock({
  title,
  hint,
  url,
  secret,
  onUrl,
  onSecret,
  onSave,
  onDelete,
}: {
  title: string;
  hint: string;
  url: string;
  secret: string;
  onUrl: (v: string) => void;
  onSecret: (v: string) => void;
  onSave: () => void;
  onDelete: () => void;
}) {
  const lang = useStudio((s) => s.lang);
  return (
    <section className="rounded-2xl border border-border bg-surface p-4">
      <h2 className="text-base font-semibold">{title}</h2>
      <p className="mt-1 text-xs text-muted">{hint}</p>
      <Field label="Realtime Database URL" value={url} onChange={onUrl} placeholder="https://your-app-default-rtdb.firebaseio.com" />
      <Field label={lang === "hi" ? "डेटाबेस सीक्रेट / auth" : "Database secret / auth"} value={secret} onChange={onSecret} secret />
      <div className="mt-3 flex gap-2">
        <button type="button" className="h-12 rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink" onClick={onSave}>
          {t(lang, "save")}
        </button>
        <button type="button" className="h-12 rounded-xl border border-border px-4 text-sm" onClick={onDelete}>
          {t(lang, "delete")}
        </button>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  secret,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  secret?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="mt-2 block text-sm">
      {label}
      <input
        type={secret ? "password" : "text"}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 h-12 w-full rounded-xl border border-border bg-bg px-3"
        autoComplete="off"
      />
    </label>
  );
}
