import { Check, Home, Mic, MicOff, Square } from "lucide-react";
import { t } from "@/lib/studio/i18n";
import { deriveChecks } from "@/lib/studio/map";
import type { Tab } from "@/lib/studio/types";
import { useStudio } from "@/lib/studio/store";

const TABS: Tab[] = ["copilot", "build", "vault", "admin", "skills", "secrets"];

export function StudioHeader({
  tab,
  onTab,
}: {
  tab: Tab;
  onTab: (tab: Tab) => void;
}) {
  const lang = useStudio((s) => s.lang);
  const setLang = useStudio((s) => s.setLang);
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-bg">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-3 py-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-accent text-accent-ink" aria-hidden="true">
          <svg viewBox="0 0 24 24" className="size-5">
            <path d="M5 18V6h6.2a3.4 3.4 0 0 1 0 6.8H5" fill="none" stroke="currentColor" strokeWidth="2.2" />
            <path d="M13.5 12.8 19 18" fill="none" stroke="currentColor" strokeWidth="2.2" />
          </svg>
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold tracking-tight">Sarfealam Auto-Studio</p>
          <p className="font-mono text-xs text-muted">Factory</p>
        </div>
        <div className="ml-auto flex rounded-xl border border-border bg-surface p-1">
          <button
            type="button"
            className={`h-9 rounded-lg px-3 text-sm font-semibold ${lang === "en" ? "bg-accent text-accent-ink" : "text-muted"}`}
            onClick={() => setLang("en")}
            aria-pressed={lang === "en"}
          >
            English
          </button>
          <button
            type="button"
            className={`h-9 rounded-lg px-3 text-sm font-semibold ${lang === "hi" ? "bg-accent text-accent-ink" : "text-muted"}`}
            onClick={() => setLang("hi")}
            aria-pressed={lang === "hi"}
          >
            हिन्दी
          </button>
        </div>
      </div>
      <nav className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-3 pb-3" aria-label="Sections">
        {TABS.map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => onTab(id)}
            className={`h-11 shrink-0 rounded-xl px-3 text-sm font-semibold ${tab === id ? "bg-accent text-accent-ink" : "bg-surface text-fg"}`}
            aria-current={tab === id ? "page" : undefined}
          >
            {t(lang, id)}
          </button>
        ))}
      </nav>
    </header>
  );
}

export function StatusStrip() {
  const lang = useStudio((s) => s.lang);
  const secrets = useStudio((s) => s.secrets);
  const health = useStudio((s) => s.health);
  const liveOn = useStudio((s) => s.liveOn);
  const healthOn = useStudio((s) => s.skillOn("secrets-health"));
  const d = deriveChecks(secrets, health, healthOn);
  const gh =
    d.github === "ok"
      ? `${t(lang, "connected")} · ${d.githubUser ?? ""}`
      : d.github === "checking"
        ? t(lang, "checking")
        : d.github === "empty"
          ? t(lang, "notSet")
          : d.github === "skipped"
            ? t(lang, "savedUnchecked")
            : t(lang, "invalid");
  const studio =
    d.studio === "ok" ? t(lang, "connected") : d.studio === "checking" ? t(lang, "checking") : d.studio === "empty" ? t(lang, "notSet") : d.studio === "skipped" ? t(lang, "savedUnchecked") : t(lang, "unreachable");
  const apps =
    d.apps === "ok" ? t(lang, "connected") : d.apps === "checking" ? t(lang, "checking") : d.apps === "empty" ? t(lang, "notSet") : d.apps === "skipped" ? t(lang, "savedUnchecked") : t(lang, "unreachable");
  return (
    <dl className="grid grid-cols-2 gap-2 font-mono text-xs sm:grid-cols-4">
      <StripItem label={t(lang, "github")} value={gh} ok={d.github === "ok"} />
      <StripItem label={t(lang, "studioFb")} value={studio} ok={d.studio === "ok"} />
      <StripItem label={t(lang, "appsFb")} value={apps} ok={d.apps === "ok"} />
      <StripItem label={t(lang, "live")} value={liveOn ? t(lang, "liveOn") : t(lang, "liveOff")} ok={liveOn} />
    </dl>
  );
}

function StripItem({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-3 py-2">
      <dt className="text-muted">{label}</dt>
      <dd className={ok ? "text-accent" : "text-fg"}>{value}</dd>
    </div>
  );
}

export function BottomBar({
  onCancel,
  onOk,
  onHome,
}: {
  onCancel: () => void;
  onOk: () => void;
  onHome: () => void;
}) {
  const lang = useStudio((s) => s.lang);
  const liveOn = useStudio((s) => s.liveOn);
  const setLive = useStudio((s) => s.setLive);
  const liveSkill = useStudio((s) => s.skillOn("live-voice"));
  const job = useStudio((s) => s.jobs.find((j) => j.id === s.activeJobId) ?? null);
  const okOn = !!job && !job.demo && job.stage >= 5 && (job.status === "testing" || job.status === "ready");
  const cancelOn = !!job && (job.status === "assembling" || job.status === "testing" || job.status === "exporting");
  return (
    <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border bg-surface">
      <div className="mx-auto grid max-w-6xl grid-cols-4 gap-2 px-3 py-2">
        <button
          type="button"
          disabled={!liveSkill}
          aria-pressed={liveOn}
          title={liveSkill ? "" : "Live voice skill is off"}
          onClick={() => setLive(!liveOn)}
          className={`flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-semibold disabled:opacity-40 ${liveOn ? "bg-accent text-accent-ink" : "bg-surface-2 text-fg"}`}
        >
          {liveOn ? <Mic className="size-4" /> : <MicOff className="size-4" />}
          {t(lang, "live")}
          {liveOn ? <span className="live-dot size-2 rounded-full bg-accent-ink" /> : null}
        </button>
        <button
          type="button"
          disabled={!cancelOn}
          onClick={onCancel}
          className="flex h-12 items-center justify-center gap-2 rounded-xl bg-surface-2 text-sm font-semibold disabled:opacity-40"
        >
          <Square className="size-4" />
          {t(lang, "cancel")}
        </button>
        <button
          type="button"
          disabled={!okOn}
          onClick={onOk}
          className="flex h-12 items-center justify-center gap-2 rounded-xl bg-accent text-sm font-semibold text-accent-ink disabled:opacity-40"
        >
          <Check className="size-4" />
          {t(lang, "ok")}
        </button>
        <button
          type="button"
          onClick={onHome}
          className="flex h-12 items-center justify-center gap-2 rounded-xl bg-surface-2 text-sm font-semibold"
        >
          <Home className="size-4" />
          {t(lang, "home")}
        </button>
      </div>
    </div>
  );
}
