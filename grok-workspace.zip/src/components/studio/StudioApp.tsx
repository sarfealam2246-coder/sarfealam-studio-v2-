import { getRouteApi } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { AdminPanel } from "@/components/studio/AdminPanel";
import { BuildPanel } from "@/components/studio/BuildPanel";
import { BottomBar, StudioHeader } from "@/components/studio/chrome";
import { CopilotPanel } from "@/components/studio/CopilotPanel";
import { SecretsPanel } from "@/components/studio/SecretsPanel";
import { SkillsPanel } from "@/components/studio/SkillsPanel";
import { VaultPanel } from "@/components/studio/VaultPanel";
import { say } from "@/lib/studio/i18n";
import {
  applyChange,
  bootStudio,
  cancelBuild,
  confirmExport,
  forceResume,
  handleUtterance,
  pollActive,
  refreshHealth,
  registerNavigator,
  rollback,
  setScreen,
  startBuild,
  startDemo,
} from "@/lib/studio/runner";
import { useStudio } from "@/lib/studio/store";
import type { Tab } from "@/lib/studio/types";

const routeApi = getRouteApi("/");

type Rec = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: SpeechEv) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

type SpeechEv = {
  resultIndex: number;
  results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }>;
};

export function StudioApp() {
  const search = routeApi.useSearch();
  const navigate = routeApi.useNavigate();
  const [ready, setReady] = useState(false);
  const liveOn = useStudio((s) => s.liveOn);
  const lang = useStudio((s) => s.lang);
  const setLive = useStudio((s) => s.setLive);
  const setHearing = useStudio((s) => s.setHearing);
  const pushMessage = useStudio((s) => s.pushMessage);
  const focusJob = useStudio((s) => s.focusJob);
  const setView = useStudio((s) => s.setView);
  const hearing = useStudio((s) => s.hearing);
  const recRef = useRef<Rec | null>(null);

  useEffect(() => {
    let stop = () => {};
    void useStudio.persist.rehydrate().then(() => {
      setReady(true);
      stop = bootStudio();
    });
    return () => stop();
  }, []);

  useEffect(() => {
    if (!ready) return;
    registerNavigator((tab, build) => {
      void navigate({ search: { tab, build: build ?? (tab === "admin" ? search.build : "") } });
    });
    setScreen(search.tab);
    if (search.build) focusJob(search.build);
  }, [ready, search.tab, search.build, navigate, focusJob]);

  useEffect(() => {
    if (!ready) return;
    if (!liveOn) {
      recRef.current?.stop();
      recRef.current = null;
      setHearing("");
      return;
    }
    if (!useStudio.getState().skillOn("live-voice")) {
      setLive(false);
      pushMessage({ role: "copilot", text: say(lang, "liveSkillOff"), kind: "note" });
      return;
    }
    const w = window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) {
      setLive(false);
      pushMessage({ role: "copilot", text: say(lang, "noSpeech"), kind: "note" });
      return;
    }
    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = lang === "hi" ? "hi-IN" : "en-US";
    rec.onresult = (ev) => {
      let interim = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const row = ev.results[i];
        const said = row?.[0]?.transcript ?? "";
        if (row?.isFinal) void handleUtterance(said);
        else interim += said;
      }
      setHearing(interim);
    };
    rec.onerror = (ev) => {
      if (ev.error === "not-allowed" || ev.error === "service-not-allowed") {
        setLive(false);
        pushMessage({ role: "copilot", text: say(useStudio.getState().lang, "micDenied"), kind: "note" });
      }
    };
    rec.onend = () => {
      if (useStudio.getState().liveOn) {
        try {
          rec.start();
        } catch {
          /* already started */
        }
      }
    };
    try {
      rec.start();
    } catch {
      setLive(false);
    }
    recRef.current = rec;
    return () => {
      rec.onend = null;
      try {
        rec.stop();
      } catch {
        /* ignore */
      }
    };
  }, [ready, liveOn, lang, setLive, setHearing, pushMessage]);

  function openTab(tab: Tab) {
    void navigate({ search: { tab, build: tab === "admin" ? search.build : "" } });
  }

  if (!ready) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg px-6 text-fg">
        <div className="text-center">
          <p className="text-lg font-semibold">Sarfealam Auto-Studio</p>
          <p className="mt-2 font-mono text-xs text-muted">…</p>
        </div>
      </main>
    );
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <StudioHeader tab={search.tab} onTab={openTab} />
      <main className="mx-auto w-full max-w-6xl px-3 pt-4 pb-28">
        {search.tab !== "copilot" && liveOn && hearing ? <p className="mb-3 font-mono text-xs text-accent">Live · {hearing}</p> : null}
        {search.tab === "copilot" ? <CopilotPanel onSend={(text) => void handleUtterance(text)} /> : null}
        {search.tab === "build" ? (
          <BuildPanel
            onAssemble={(prompt) => void startBuild(prompt)}
            onDemo={(prompt) => void startDemo(prompt)}
            onChange={(text) => void applyChange(text)}
            onRollback={rollback}
            onResume={() => {
              setView("factory");
              forceResume();
            }}
          />
        ) : null}
        {search.tab === "vault" ? (
          <VaultPanel
            onOpen={(job) => {
              focusJob(job.id);
              setView(job.status === "cancelled" ? "home" : "factory");
              openTab("build");
            }}
            onPoll={(id) => {
              focusJob(id);
              void pollActive();
            }}
            onRetry={(id) => {
              focusJob(id);
              void confirmExport();
            }}
          />
        ) : null}
        {search.tab === "admin" ? <AdminPanel buildId={search.build} onPoll={() => void pollActive()} /> : null}
        {search.tab === "skills" ? <SkillsPanel /> : null}
        {search.tab === "secrets" ? <SecretsPanel onSaved={() => void refreshHealth()} /> : null}
      </main>
      <BottomBar onCancel={cancelBuild} onOk={() => void confirmExport()} onHome={() => { setView("home"); openTab("build"); }} />
    </div>
  );
}
