import { t } from "@/lib/studio/i18n";
import { downloadZip } from "@/lib/studio/zip";
import { useStudio } from "@/lib/studio/store";
import type { Job } from "@/lib/studio/types";

export function VaultPanel({
  onOpen,
  onPoll,
  onRetry,
}: {
  onOpen: (job: Job) => void;
  onPoll: (id: string) => void;
  onRetry: (id: string) => void;
}) {
  const lang = useStudio((s) => s.lang);
  const jobs = useStudio((s) => s.jobs);
  const ordered = [...jobs].sort((a, b) => b.updatedAt - a.updatedAt);
  return (
    <section className="flex flex-col gap-3">
      <div className="rounded-2xl border border-border bg-surface p-4">
        <h1 className="text-lg font-semibold">{t(lang, "vault")}</h1>
        <p className="mt-1 text-sm text-muted">
          {lang === "hi"
            ? "हर बिल्ड की स्थिति, APK और एडमिन लिंक यहीं हैं। लिंक तभी जब वे सच में बनें।"
            : "Every build’s status, APK, and Admin link live here. Links appear only when they actually exist."}
        </p>
      </div>
      {ordered.length === 0 ? (
        <p className="rounded-2xl border border-border bg-surface px-4 py-6 text-sm text-muted">
          {lang === "hi" ? "अभी कोई बिल्ड नहीं।" : "No builds yet."}
        </p>
      ) : (
        <ul className="flex flex-col gap-2">
          {ordered.map((job) => (
            <li key={job.id} className="rounded-2xl border border-border bg-surface p-4">
              <button type="button" className="w-full text-left" onClick={() => onOpen(job)}>
                <p className="font-semibold">{job.title}</p>
                <p className="mt-1 font-mono text-xs text-muted">
                  {job.kind} · {job.engine === "godot" ? "Godot 4" : "Flutter"} · {new Date(job.createdAt).toLocaleString()} · {job.demo ? "demo" : job.status}
                </p>
              </button>
              <LinkRow label={t(lang, "apk")} href={job.apkLink} detail={job.apkDetail || (lang === "hi" ? "अभी कोई APK लिंक नहीं" : "No APK link yet")} />
              <LinkRow label={t(lang, "adminLink")} href={job.adminLink} detail={job.adminDetail || (lang === "hi" ? "अभी कोई एडमिन लिंक नहीं" : "No Admin link yet")} />
              {job.actionsUrl && job.actionsUrl !== job.apkLink ? (
                <LinkRow label="Actions" href={job.actionsUrl} detail={lang === "hi" ? "रन पेज · APK नहीं" : "Run page · not an APK"} />
              ) : null}
              <div className="mt-3 flex flex-wrap gap-2">
                {job.files?.length ? (
                  <button type="button" className="h-11 rounded-xl bg-surface-2 px-3 text-sm font-semibold" onClick={() => downloadZip(job.files ?? [], `${job.title.replace(/\s+/g, "-").slice(0, 24) || "export"}.zip`)}>
                    {t(lang, "download")}
                  </button>
                ) : null}
                {job.repoOwner ? (
                  <button type="button" className="h-11 rounded-xl border border-border px-3 text-sm font-semibold" onClick={() => onPoll(job.id)}>
                    {t(lang, "poll")}
                  </button>
                ) : null}
                {job.apkState === "push-failed" ? (
                  <button type="button" className="h-11 rounded-xl border border-border px-3 text-sm font-semibold" onClick={() => onRetry(job.id)}>
                    {t(lang, "retryExport")}
                  </button>
                ) : null}
              </div>
              <p className="mt-2 text-xs text-muted">{t(lang, "sourceNotApk")}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function LinkRow({ label, href, detail }: { label: string; href: string | null; detail: string }) {
  return (
    <p className="mt-2 text-sm">
      <span className="text-muted">{label}: </span>
      {href ? (
        <a className="break-all text-accent underline" href={href} target="_blank" rel="noreferrer">
          {href}
        </a>
      ) : (
        <span>{detail}</span>
      )}
    </p>
  );
}
