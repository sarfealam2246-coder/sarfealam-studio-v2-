import { Volume2 } from "lucide-react";
import { useState } from "react";
import { t } from "@/lib/studio/i18n";
import { speakText } from "@/lib/studio/runner";
import { useStudio } from "@/lib/studio/store";

export function CopilotPanel({ onSend }: { onSend: (text: string) => void }) {
  const lang = useStudio((s) => s.lang);
  const messages = useStudio((s) => s.messages);
  const hearing = useStudio((s) => s.hearing);
  const liveOn = useStudio((s) => s.liveOn);
  const [text, setText] = useState("");
  return (
    <section className="flex flex-col gap-3">
      <div className="rounded-2xl border border-border bg-surface p-4">
        <h1 className="text-lg font-semibold">{t(lang, "copilot")}</h1>
        <p className="mt-1 text-sm text-muted">
          {lang === "hi"
            ? "लाइव एक कॉल है: चालू करें और बोलें। टाइप हमेशा खुला है। रिकॉर्ड करके भेजना मुख्य तरीका नहीं है।"
            : "Live is a call: turn it on and speak. Typing stays open. Record-then-send is not the main mode."}
        </p>
      </div>
      <ol className="flex flex-col gap-2" aria-live="polite">
        {messages.map((m) => (
          <li key={m.id} className={`rounded-2xl border border-border px-4 py-3 ${m.role === "user" ? "bg-surface-2" : "bg-surface"}`}>
            <div className="mb-1 flex items-center justify-between gap-2">
              <span className="font-mono text-xs text-muted">{m.role === "user" ? (lang === "hi" ? "आप" : "You") : "Co-pilot"}</span>
              {m.role === "copilot" ? (
                <button type="button" className="inline-flex h-9 items-center gap-1 rounded-lg px-2 text-xs text-muted" onClick={() => speakText(m.text)}>
                  <Volume2 className="size-3.5" />
                  {lang === "hi" ? "डिवाइस आवाज़" : "Device voice"}
                </button>
              ) : null}
            </div>
            <p className="whitespace-pre-wrap text-sm leading-6">{m.text}</p>
          </li>
        ))}
      </ol>
      {liveOn ? (
        <p className="font-mono text-xs text-accent">
          {t(lang, "live")} {t(lang, "liveOn")}
          {hearing ? ` · ${t(lang, "hearing")}: ${hearing}` : ""}
        </p>
      ) : null}
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          const next = text.trim();
          if (!next) return;
          setText("");
          onSend(next);
        }}
      >
        <label className="sr-only" htmlFor="copilot-input">
          {t(lang, "copilot")}
        </label>
        <input
          id="copilot-input"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={lang === "hi" ? "लिखें या कमांड दें" : "Type or give a command"}
          className="h-12 min-w-0 flex-1 rounded-xl border border-border bg-surface-2 px-3 text-sm"
        />
        <button type="submit" className="h-12 rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink">
          {t(lang, "send")}
        </button>
      </form>
    </section>
  );
}
