import { createFileRoute } from "@tanstack/react-router";
import { StudioApp } from "@/components/studio/StudioApp";

export type StudioSearch = { tab: "copilot" | "build" | "vault" | "admin" | "skills" | "secrets"; build: string };

const TABS = ["copilot", "build", "vault", "admin", "skills", "secrets"] as const;

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): StudioSearch => {
    const tab = TABS.includes(search.tab as StudioSearch["tab"]) ? (search.tab as StudioSearch["tab"]) : "copilot";
    return { tab, build: typeof search.build === "string" ? search.build : "" };
  },
  component: Home,
});

function Home() {
  return <StudioApp />;
}
