import { createServerFn } from "@tanstack/react-start";

type GhFile = { path: string; content: string };

function headers(token: string): HeadersInit {
  return {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "sarfealam-auto-studio",
    "Content-Type": "application/json",
  };
}

async function gh(token: string, path: string, init?: RequestInit): Promise<Response> {
  return fetch(`https://api.github.com${path}`, {
    ...init,
    headers: { ...headers(token), ...(init?.headers ?? {}) },
    signal: AbortSignal.timeout(28000),
  });
}

export const githubWhoami = createServerFn({ method: "POST" })
  .validator((input: { token: string }) => {
    const token = input?.token?.trim?.() ?? "";
    if (token.length < 8) throw new Error("Token missing");
    return { token };
  })
  .handler(async ({ data }) => {
    const res = await gh(data.token, "/user");
    if (res.status === 401 || res.status === 403) return { ok: false as const, error: "Token rejected by GitHub" };
    if (!res.ok) return { ok: false as const, error: `GitHub HTTP ${res.status}` };
    const body = (await res.json()) as { login?: string };
    if (!body.login) return { ok: false as const, error: "No login on this token" };
    return { ok: true as const, login: body.login };
  });

export const githubPush = createServerFn({ method: "POST" })
  .validator((input: { token: string; repoName: string; description: string; files: GhFile[] }) => {
    const token = input?.token?.trim?.() ?? "";
    if (token.length < 8) throw new Error("Token missing");
    const repoName = (input.repoName || "").toLowerCase().replace(/[^a-z0-9._-]/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
    if (!repoName) throw new Error("Repo name missing");
    const files = Array.isArray(input.files) ? input.files : [];
    if (files.length === 0 || files.length > 40) throw new Error("Unexpected file count");
    for (const file of files) {
      if (!file.path || file.path.includes("..") || file.path.startsWith("/") || file.path.length > 180) {
        throw new Error("Bad path");
      }
      if (typeof file.content !== "string" || file.content.length > 100_000) throw new Error("File too large");
    }
    return {
      token,
      repoName,
      description: (input.description || "Sarfealam Auto-Studio export").slice(0, 180),
      files,
    };
  })
  .handler(async ({ data }) => {
    const created = await gh(data.token, "/user/repos", {
      method: "POST",
      body: JSON.stringify({
        name: data.repoName,
        description: data.description,
        private: true,
        auto_init: false,
      }),
    });
    if (created.status === 401 || created.status === 403) {
      return { ok: false as const, error: "GitHub rejected the token. It needs the repo scope." };
    }
    if (!created.ok) {
      const text = await created.text();
      return { ok: false as const, error: `Could not create repo (HTTP ${created.status}). ${text.slice(0, 140)}` };
    }
    const repo = (await created.json()) as { full_name?: string; html_url?: string; owner?: { login?: string }; name?: string };
    const owner = repo.owner?.login;
    const name = repo.name;
    if (!owner || !name) return { ok: false as const, error: "GitHub did not return a repository" };

    const blobs: { path: string; sha: string }[] = [];
    for (const file of data.files) {
      const blobRes = await gh(data.token, `/repos/${owner}/${name}/git/blobs`, {
        method: "POST",
        body: JSON.stringify({ content: file.content, encoding: "utf-8" }),
      });
      if (!blobRes.ok) return { ok: false as const, error: `Blob failed for ${file.path} (HTTP ${blobRes.status})` };
      const blob = (await blobRes.json()) as { sha?: string };
      if (!blob.sha) return { ok: false as const, error: `Blob missing sha for ${file.path}` };
      blobs.push({ path: file.path, sha: blob.sha });
    }

    const treeRes = await gh(data.token, `/repos/${owner}/${name}/git/trees`, {
      method: "POST",
      body: JSON.stringify({
        tree: blobs.map((b) => ({ path: b.path, mode: "100644", type: "blob", sha: b.sha })),
      }),
    });
    if (!treeRes.ok) return { ok: false as const, error: `Tree failed (HTTP ${treeRes.status})` };
    const tree = (await treeRes.json()) as { sha?: string };
    if (!tree.sha) return { ok: false as const, error: "Tree missing sha" };

    const commitRes = await gh(data.token, `/repos/${owner}/${name}/git/commits`, {
      method: "POST",
      body: JSON.stringify({ message: "Sarfealam Auto-Studio export", tree: tree.sha, parents: [] }),
    });
    if (!commitRes.ok) return { ok: false as const, error: `Commit failed (HTTP ${commitRes.status})` };
    const commit = (await commitRes.json()) as { sha?: string };
    if (!commit.sha) return { ok: false as const, error: "Commit missing sha" };

    const refRes = await gh(data.token, `/repos/${owner}/${name}/git/refs`, {
      method: "POST",
      body: JSON.stringify({ ref: "refs/heads/main", sha: commit.sha }),
    });
    if (!refRes.ok) return { ok: false as const, error: `Branch failed (HTTP ${refRes.status})` };

    return {
      ok: true as const,
      owner,
      repo: name,
      repoUrl: repo.html_url ?? `https://github.com/${owner}/${name}`,
      actionsUrl: `https://github.com/${owner}/${name}/actions`,
    };
  });

export const githubPoll = createServerFn({ method: "POST" })
  .validator((input: { token: string; owner: string; repo: string }) => {
    const token = input?.token?.trim?.() ?? "";
    if (token.length < 8) throw new Error("Token missing");
    const owner = (input.owner || "").trim();
    const repo = (input.repo || "").trim();
    if (!/^[\w.-]+$/.test(owner) || !/^[\w.-]+$/.test(repo)) throw new Error("Bad repository");
    return { token, owner, repo };
  })
  .handler(async ({ data }) => {
    const runsRes = await gh(data.token, `/repos/${data.owner}/${data.repo}/actions/runs?per_page=5`);
    if (runsRes.status === 401 || runsRes.status === 403) return { ok: false as const, error: "Token rejected while polling" };
    if (!runsRes.ok) return { ok: false as const, error: `Runs HTTP ${runsRes.status}` };
    const runsBody = (await runsRes.json()) as {
      workflow_runs?: { id: number; status: string; conclusion: string | null; html_url: string; run_number: number }[];
    };
    const artRes = await gh(data.token, `/repos/${data.owner}/${data.repo}/actions/artifacts?per_page=10`);
    if (!artRes.ok) return { ok: false as const, error: `Artifacts HTTP ${artRes.status}` };
    const artBody = (await artRes.json()) as { artifacts?: { name: string; expired: boolean; size_in_bytes: number }[] };
    const runs = (runsBody.workflow_runs ?? []).map((r) => ({
      id: r.id,
      status: r.status,
      conclusion: r.conclusion,
      htmlUrl: r.html_url,
      number: r.run_number,
    }));
    const artifacts = (artBody.artifacts ?? [])
      .filter((a) => !a.expired)
      .map((a) => ({ name: a.name, size: a.size_in_bytes }));
    return { ok: true as const, runs, artifacts };
  });
