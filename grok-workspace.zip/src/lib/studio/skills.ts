import type { Lang, SkillDef } from "./types.ts";

export const SKILLS: SkillDef[] = [
  { id: "prompt-match", group: "pipeline", en: "Prompt → skill match", hi: "प्रॉम्प्ट → स्किल मिलान", detailEn: "Attaches product skills only when the prompt asks and the toggle is on.", detailHi: "प्रॉम्प्ट माँगे और टॉगल चालू हो तभी प्रोडक्ट स्किल जुड़ती है।" },
  { id: "assembly-stages", group: "pipeline", en: "Assembly stages (Display A)", hi: "असेंबली चरण (डिस्प्ले A)", detailEn: "Runs Shell → Test. Off blocks the build.", detailHi: "शेल से टेस्ट तक। बंद हो तो बिल्ड नहीं चलेगा।" },
  { id: "system-map", group: "pipeline", en: "System map (Display B)", hi: "सिस्टम मैप (डिस्प्ले B)", detailEn: "Team chips and navigation. Off hides the live map.", detailHi: "टीम चिप्स। बंद हो तो लाइव मैप नहीं चलेगा।" },
  { id: "job-survivor", group: "pipeline", en: "Background job survivor", hi: "बैकग्राउंड जॉब सर्वाइवर", detailEn: "Continues an assembling job after reload.", detailHi: "रीलोड के बाद असेंबली जारी रखता है।" },
  { id: "live-voice", group: "pipeline", en: "Live voice command", hi: "लाइव वॉइस कमांड", detailEn: "Call-style Live session. Off disables the Live control.", detailHi: "कॉल-शैली लाइव। बंद हो तो लाइव बटन बंद।" },
  { id: "screen-aware", group: "pipeline", en: "Screen-aware co-pilot", hi: "स्क्रीन-अवेयर को-पायलट", detailEn: "Answers include tab, stage, chip, and secret health.", detailHi: "जवाब में टैब, चरण, चिप और सीक्रेट स्वास्थ्य।" },
  { id: "secrets-health", group: "pipeline", en: "Secrets health", hi: "सीक्रेट स्वास्थ्य", detailEn: "Re-checks GitHub and Firebase on save and on launch.", detailHi: "सेव और लॉन्च पर GitHub व Firebase जाँच।" },
  { id: "rate-fallback", group: "pipeline", en: "Rate-limit fallback", hi: "रेट-लिमिट फॉलबैक", detailEn: "On HTTP 429/5xx, tries the next key and shows it on the map.", detailHi: "429/5xx पर अगली कुंजी और मैप पर नोट।" },
  { id: "self-heal", group: "pipeline", en: "Self-heal / critic", hi: "सेल्फ-हील / क्रिटिक", detailEn: "Up to 3 attempts when the model output is unusable.", detailHi: "मॉडल आउटपुट खराब हो तो 3 प्रयास।" },
  { id: "checkpoint", group: "pipeline", en: "Checkpoint / rollback", hi: "चेकपॉइंट / रोलबैक", detailEn: "Saves the spec before a change so you can roll back.", detailHi: "बदलाव से पहले स्पेक सेव, वापसी संभव।" },
  { id: "vision-qa", group: "pipeline", en: "Vision QA on preview", hi: "प्रीव्यू पर विज़न QA", detailEn: "Runs only with a Vision-tagged key (or a single key).", detailHi: "सिर्फ Vision कुंजी या अकेली कुंजी पर।" },
  { id: "engine-picker", group: "pipeline", en: "Engine picker", hi: "इंजन चयन", detailEn: "Game/3D prompts use Godot 4; apps use Flutter. Off forces Flutter.", detailHi: "गेम/3D पर Godot 4, ऐप पर Flutter। बंद हो तो Flutter।" },
  { id: "flutter-path", group: "pipeline", en: "Flutter project + workflow", hi: "Flutter प्रोजेक्ट + वर्कफ़्लो", detailEn: "Writes the Flutter tree and Android APK workflow.", detailHi: "Flutter ट्री और Android APK वर्कफ़्लो लिखता है।" },
  { id: "godot-path", group: "pipeline", en: "Godot 4 project + workflow", hi: "Godot 4 प्रोजेक्ट + वर्कफ़्लो", detailEn: "Writes the Godot 4 tree and Android export workflow.", detailHi: "Godot 4 ट्री और Android एक्सपोर्ट वर्कफ़्लो।" },
  { id: "github-connect", group: "pipeline", en: "GitHub connect / push", hi: "GitHub कनेक्ट / पुश", detailEn: "Validates Token1 and pushes the export when you press OK.", detailHi: "Token1 जाँच और OK पर पुश।" },
  { id: "actions-poll", group: "pipeline", en: "Actions status poll", hi: "Actions स्थिति पोल", detailEn: "Polls the workflow. No artifact means no APK link.", detailHi: "वर्कफ़्लो पोल। आर्टिफैक्ट नहीं तो APK लिंक नहीं।" },
  { id: "publish-apk", group: "pipeline", en: "Publish APK link", hi: "APK लिंक प्रकाशित", detailEn: "Writes the APK slot only when an Actions artifact exists.", detailHi: "APK स्लॉट सिर्फ आर्टिफैक्ट पर।" },
  { id: "publish-admin", group: "pipeline", en: "Publish Admin link", hi: "एडमिन लिंक प्रकाशित", detailEn: "Writes the in-studio Admin URL for that build after export.", detailHi: "एक्सपोर्ट के बाद उस बिल्ड का एडमिन URL।" },
  { id: "studio-firebase", group: "pipeline", en: "Studio Firebase sync", hi: "स्टूडियो Firebase सिंक", detailEn: "Syncs jobs, language, and stage — never API keys.", detailHi: "जॉब, भाषा, चरण सिंक — API कुंजी नहीं।" },
  { id: "apps-firebase", group: "pipeline", en: "Apps Firebase inject", hi: "ऐप्स Firebase इंजेक्ट", detailEn: "Puts Apps Firebase into the local export package only.", detailHi: "Apps Firebase सिर्फ लोकल एक्सपोर्ट में।" },
  { id: "research-bot", group: "pipeline", en: "Research bot", hi: "रिसर्च बॉट", detailEn: "Wikipedia lookup when the prompt needs outside facts.", detailHi: "बाहर के तथ्यों के लिए Wikipedia।" },
  { id: "asset-hint", group: "pipeline", en: "Open-source asset hint", hi: "ओपन-सोर्स एसेट संकेत", detailEn: "Names permissive asset sources in the export README. Does not fake downloads.", detailHi: "README में अनुमति वाले स्रोत। नकली डाउनलोड नहीं।" },
  { id: "otp-auth", group: "product", en: "Gmail / phone OTP auth", hi: "जीमेल / फोन OTP", detailEn: "Auth screen when the prompt asks.", detailHi: "प्रॉम्प्ट माँगे तो ऑथ स्क्रीन।", keywords: ["otp", "login", "sign in", "sign-in", "phone auth", "gmail", "email login"] },
  { id: "bottom-nav", group: "product", en: "Bottom navigation", hi: "बॉटम नेविगेशन", detailEn: "Bottom tabs in the preview and Flutter shell.", detailHi: "प्रीव्यू और Flutter में बॉटम टैब।", keywords: ["bottom nav", "bottom navigation", "tabs", "tab bar"] },
  { id: "profile", group: "product", en: "Profile", hi: "प्रोफ़ाइल", detailEn: "Profile screen.", detailHi: "प्रोफ़ाइल स्क्रीन।", keywords: ["profile", "account page", "my account"] },
  { id: "search", group: "product", en: "Search", hi: "सर्च", detailEn: "Search field.", detailHi: "सर्च फ़ील्ड।", keywords: ["search", "find"] },
  { id: "lists-forms", group: "product", en: "Lists & forms", hi: "सूची और फ़ॉर्म", detailEn: "List and form screens.", detailHi: "सूची और फ़ॉर्म।", keywords: ["list", "form", "crud", "inventory", "catalog"] },
  { id: "wallet", group: "product", en: "Wallet / balance", hi: "वॉलेट / बैलेंस", detailEn: "Balance surface.", detailHi: "बैलेंस सतह।", keywords: ["wallet", "balance", "upi", "payment"] },
  { id: "vip", group: "product", en: "VIP plan unlock", hi: "VIP प्लान", detailEn: "VIP / plan note.", detailHi: "VIP / प्लान।", keywords: ["vip", "subscription", "premium plan", "unlock"] },
  { id: "maps-booking", group: "product", en: "Maps / booking style", hi: "मैप / बुकिंग", detailEn: "Booking-style layout (no fake map SDK).", detailHi: "बुकिंग लेआउट (नकली मैप SDK नहीं)।", keywords: ["map", "booking", "ride", "cab", "taxi"] },
  { id: "game-controls", group: "product", en: "3D / game preview controls", hi: "गेम प्रीव्यू कंट्रोल", detailEn: "Steer, gas, and brake once stage 5 is reached.", detailHi: "चरण 5 पर स्टीयर, गैस, ब्रेक।", keywords: ["steer", "gas", "brake", "hud", "joystick", "racing", "kart"] },
  { id: "card-table", group: "product", en: "Card-table logic", hi: "कार्ड टेबल", detailEn: "Simple card table in the preview.", detailHi: "प्रीव्यू में साधारण कार्ड टेबल।", keywords: ["card", "poker", "solitaire", "table game"] },
  { id: "i18n-strings", group: "product", en: "Hindi-English strings", hi: "हिन्दी-अंग्रेज़ी स्ट्रिंग", detailEn: "Writes both languages into the export.", detailHi: "एक्सपोर्ट में दोनों भाषाएँ।", keywords: ["hindi", "bilingual", "i18n", "हिंदी", "हिन्दी"] },
  { id: "ads-iap", group: "product", en: "Ads / IAP hook", hi: "ऐड्स / IAP", detailEn: "A labeled hook only — no live ad network.", detailHi: "सिर्फ हुक — कोई लाइव ऐड नेटवर्क नहीं।", keywords: ["ads", "admob", "iap", "in-app purchase"] },
  { id: "theme-variants", group: "product", en: "Theme variants", hi: "थीम वेरिएंट", detailEn: "Light/dark note in the spec export.", detailHi: "लाइट/डार्क नोट।", keywords: ["theme", "dark mode", "light mode"] },
  { id: "store-listing", group: "product", en: "Store listing draft", hi: "स्टोर लिस्टिंग ड्राफ्ट", detailEn: "Writes STORE_LISTING.md.", detailHi: "STORE_LISTING.md लिखता है।", keywords: ["play store", "store listing", "app store"] },
  { id: "a11y", group: "product", en: "Accessibility pass", hi: "एक्सेसिबिलिटी", detailEn: "Semantics labels in the Flutter shell.", detailHi: "Flutter में सिमेंटिक्स लेबल।", keywords: ["accessibility", "a11y", "screen reader"] },
  { id: "offline-hint", group: "product", en: "Offline cache hint", hi: "ऑफ़लाइन संकेत", detailEn: "README hint only.", detailHi: "सिर्फ README संकेत।", keywords: ["offline", "cache"] },
  { id: "perf-hint", group: "product", en: "Performance budget hint", hi: "परफ़ॉर्मेंस बजट", detailEn: "README hint only.", detailHi: "सिर्फ README संकेत।", keywords: ["performance", "perf budget", "60fps"] },
  { id: "release-notes", group: "product", en: "Release notes", hi: "रिलीज़ नोट्स", detailEn: "Writes RELEASE_NOTES.md.", detailHi: "RELEASE_NOTES.md लिखता है।", keywords: ["release notes", "changelog"] },
  { id: "prompt-expand", group: "product", en: "Prompt expand / spec", hi: "प्रॉम्प्ट विस्तार", detailEn: "Asks the model to expand a short idea. Off keeps the spec literal.", detailHi: "मॉडल से विस्तार। बंद हो तो शाब्दिक स्पेक।" },
];

export function skillOn(map: Record<string, boolean>, id: string): boolean {
  return map[id] !== false;
}

export function defaultSkillMap(): Record<string, boolean> {
  const map: Record<string, boolean> = {};
  for (const s of SKILLS) map[s.id] = true;
  return map;
}

export function skillLabel(id: string, lang: Lang): string {
  const s = SKILLS.find((x) => x.id === id);
  if (!s) return id;
  return lang === "hi" ? s.hi : s.en;
}

export function matchProductSkills(
  prompt: string,
  enabled: Record<string, boolean>,
): { matched: string[]; skipped: { id: string; reason: string }[] } {
  if (!skillOn(enabled, "prompt-match")) {
    return {
      matched: [],
      skipped: [{ id: "prompt-match", reason: "prompt→skill match is off" }],
    };
  }
  const hay = prompt.toLowerCase();
  const matched: string[] = [];
  const skipped: { id: string; reason: string }[] = [];
  for (const s of SKILLS) {
    if (s.group !== "product" || !s.keywords?.length) continue;
    const hit = s.keywords.some((k) => hay.includes(k.toLowerCase()));
    if (!hit) continue;
    if (!skillOn(enabled, s.id)) skipped.push({ id: s.id, reason: "skill off" });
    else matched.push(s.id);
  }
  return { matched, skipped };
}

const GAME_RE =
  /\b(game|3d|godot|racing|kart|shooter|platformer|hud|steer|player controller|open world)\b/i;
const APP_FORCE_RE = /\b(flutter|e-?commerce|invoice|crm|wallet app|shop app)\b/i;

export function pickEngine(
  prompt: string,
  enabled: Record<string, boolean>,
): { engine: "flutter" | "godot"; kind: "app" | "game"; note: string } {
  const game = GAME_RE.test(prompt);
  const forceApp = APP_FORCE_RE.test(prompt);
  const kind: "app" | "game" = game && !forceApp ? "game" : "app";
  if (!skillOn(enabled, "engine-picker")) {
    return {
      engine: "flutter",
      kind,
      note: "engine picker off — Flutter path",
    };
  }
  if (/\bgodot\b/i.test(prompt) || (game && !forceApp && !/\bflutter\b/i.test(prompt))) {
    return { engine: "godot", kind: "game", note: "engine picker · Godot 4" };
  }
  return { engine: "flutter", kind: "app", note: "engine picker · Flutter" };
}
