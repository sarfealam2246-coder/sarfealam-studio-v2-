import { say, t } from "./i18n.ts";
import { buildChips, deriveChecks } from "./map.ts";
import type { Health, Job, Lang, Secrets, Tab } from "./types.ts";

export function statusBrief(input: {
  lang: Lang;
  tab: Tab;
  secrets: Secrets;
  health: Health;
  skills: Record<string, boolean>;
  job: Job | null;
  liveOn: boolean;
}): string {
  const healthOn = input.skills["secrets-health"] !== false;
  const derived = deriveChecks(input.secrets, input.health, healthOn);
  const map = buildChips({
    secrets: input.secrets,
    health: input.health,
    systemMapOn: input.skills["system-map"] !== false,
    selfHealOn: input.skills["self-heal"] !== false,
    researchOn: input.skills["research-bot"] !== false,
    job: input.job,
    secretsHealthOn: healthOn,
  });
  const active = map.chips.find((c) => c.state === "active");
  const job = input.job;
  const jobLine = job
    ? `${job.title} · ${job.demo ? "demo" : job.status} · stage ${job.stage}/5${job.error ? ` · ${job.error}` : ""}`
    : input.lang === "hi"
      ? "कोई सक्रिय जॉब नहीं"
      : "No active job";
  const gh =
    derived.github === "ok"
      ? `${t(input.lang, "connected")} · ${derived.githubUser ?? ""}`
      : derived.githubDetail;
  const screen = input.skills["screen-aware"] === false
    ? input.lang === "hi"
      ? "स्क्रीन-अवेयर स्किल बंद है।"
      : "Screen-aware skill is off."
    : input.lang === "hi"
      ? `टैब ${input.tab}। सक्रिय चिप: ${active ? active.label : "कोई नहीं"}। लाइव ${input.liveOn ? "चालू" : "बंद"}।`
      : `Tab ${input.tab}. Active chip: ${active ? active.label : "none"}. Live ${input.liveOn ? "ON" : "OFF"}.`;
  const missing = [
    derived.github !== "ok" ? derived.githubDetail : "",
    derived.studio === "bad" ? derived.studioDetail : "",
    derived.apps === "bad" ? derived.appsDetail : "",
  ].filter(Boolean);
  const miss = missing.length
    ? (input.lang === "hi" ? `समस्या: ${missing.join(" · ")}` : `Issues: ${missing.join(" · ")}`)
    : input.lang === "hi"
      ? "कोई हेल्थ त्रुटि नहीं।"
      : "No health errors.";
  return [screen, jobLine, `GitHub: ${gh}`, miss, say(input.lang, "help")].join("\n");
}
