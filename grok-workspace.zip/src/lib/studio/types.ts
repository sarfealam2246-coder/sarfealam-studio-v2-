export type Lang = "en" | "hi";

export type Tab = "copilot" | "build" | "vault" | "admin" | "skills" | "secrets";

export type ProviderId =
  | "gemini"
  | "groq"
  | "openai"
  | "nvidia"
  | "xai"
  | "qwen"
  | "anthropic"
  | "custom";

export type Tag = "general" | "code" | "fast" | "vision" | "primary" | "fallback";

export type Dept = "brain" | "code" | "fast" | "vision" | "reason";

export type ApiKey = {
  id: string;
  label: string;
  provider: ProviderId;
  model: string;
  baseUrl: string;
  secret: string;
  tags: Tag[];
};

export type Secrets = {
  keys: ApiKey[];
  token1: string;
  token2: string;
  voiceKey: string;
  studioUrl: string;
  studioKey: string;
  appsUrl: string;
  appsKey: string;
};

export type CheckState = "empty" | "checking" | "ok" | "bad" | "skipped";

export type Health = {
  github: CheckState;
  githubUser: string | null;
  githubDetail: string;
  studio: CheckState;
  studioDetail: string;
  apps: CheckState;
  appsDetail: string;
};

export type SkillGroup = "pipeline" | "product";

export type SkillDef = {
  id: string;
  group: SkillGroup;
  en: string;
  hi: string;
  detailEn: string;
  detailHi: string;
  keywords?: string[];
};

export type ProductSpec = {
  title: string;
  kind: "app" | "game";
  engine: "flutter" | "godot";
  tagline: string;
  screens: { name: string; blurb: string }[];
  hero: string;
  controls: string[];
  demo: boolean;
};

export type JobStatus =
  | "assembling"
  | "testing"
  | "exporting"
  | "ready"
  | "error"
  | "cancelled";

export type ApkState =
  | "none"
  | "blocked-token"
  | "blocked-skill"
  | "queued"
  | "artifact"
  | "push-failed";

export type ProjectFile = { path: string; content: string };

export type Job = {
  id: string;
  title: string;
  prompt: string;
  kind: "app" | "game";
  engine: "flutter" | "godot";
  status: JobStatus;
  stage: number;
  matchedSkills: string[];
  skippedSkills: { id: string; reason: string }[];
  createdAt: number;
  updatedAt: number;
  spec: ProductSpec | null;
  specHistory: ProductSpec[];
  apkState: ApkState;
  apkLink: string | null;
  apkDetail: string;
  adminLink: string | null;
  adminDetail: string;
  actionsUrl: string | null;
  repoUrl: string | null;
  error: string | null;
  healAttempts: number;
  activeKeyId: string | null;
  fallbackNote: string | null;
  criticNote: string | null;
  visionNote: string | null;
  testLog: string[];
  files: ProjectFile[] | null;
  bannerOn: boolean;
  notification: string;
  vipNote: string;
  demo: boolean;
  repoOwner: string | null;
  repoName: string | null;
};

export type ChatMessage = {
  id: string;
  role: "user" | "copilot";
  text: string;
  ts: number;
  kind?: "welcome" | "note";
};

export type ChipState = "muted" | "ready" | "active" | "done" | "error";

export type Chip = {
  id: string;
  label: string;
  state: ChipState;
  reason: string;
  caption: string;
};

export const EMPTY_SECRETS: Secrets = {
  keys: [],
  token1: "",
  token2: "",
  voiceKey: "",
  studioUrl: "",
  studioKey: "",
  appsUrl: "",
  appsKey: "",
};

export const EMPTY_HEALTH: Health = {
  github: "empty",
  githubUser: null,
  githubDetail: "",
  studio: "empty",
  studioDetail: "",
  apps: "empty",
  appsDetail: "",
};
