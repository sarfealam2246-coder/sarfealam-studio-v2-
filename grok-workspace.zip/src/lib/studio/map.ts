import type { Chip, Health, Job, Secrets } from "./types.ts";

export type Derived = {
  github: Health["github"];
  githubUser: string | null;
  githubDetail: string;
  studio: Health["studio"];
  studioDetail: string;
  apps: Health["apps"];
  appsDetail: string;
};

export function deriveChecks(
  secrets: Secrets,
  health: Health,
  secretsHealthOn: boolean,
): Derived {
  const github: Derived["github"] = !secrets.token1.trim()
    ? "empty"
    : !secretsHealthOn
      ? "skipped"
      : health.github === "empty"
        ? "checking"
        : health.github;
  const studio: Derived["studio"] = !secrets.studioUrl.trim() && !secrets.studioKey.trim()
    ? "empty"
    : !secrets.studioUrl.trim() || !secrets.studioKey.trim()
      ? "bad"
      : !secretsHealthOn
        ? "skipped"
        : health.studio === "empty"
          ? "checking"
          : health.studio;
  const apps: Derived["apps"] = !secrets.appsUrl.trim() && !secrets.appsKey.trim()
    ? "empty"
    : !secrets.appsUrl.trim() || !secrets.appsKey.trim()
      ? "bad"
      : !secretsHealthOn
        ? "skipped"
        : health.apps === "empty"
          ? "checking"
          : health.apps;
  return {
    github,
    githubUser: github === "ok" ? health.githubUser : null,
    githubDetail:
      github === "empty"
        ? "missing GitHub token"
        : github === "skipped"
          ? "saved · secrets health off"
          : github === "checking"
            ? "checking token"
            : health.githubDetail || (github === "ok" ? "token accepted" : "token rejected"),
    studio,
    studioDetail:
      studio === "empty"
        ? "missing Studio Firebase"
        : !secrets.studioUrl.trim() || !secrets.studioKey.trim()
          ? "Studio Firebase needs both URL and key"
          : studio === "skipped"
            ? "saved · secrets health off"
            : studio === "checking"
              ? "checking"
              : health.studioDetail || "",
    apps,
    appsDetail:
      apps === "empty"
        ? "missing Apps Firebase"
        : !secrets.appsUrl.trim() || !secrets.appsKey.trim()
          ? "Apps Firebase needs both URL and key"
          : apps === "skipped"
            ? "saved · secrets health off"
            : apps === "checking"
              ? "checking"
              : health.appsDetail || "",
  };
}

function stageCaption(stage: number, kind: "app" | "game"): string {
  if (stage <= 1) return "Brain · framing the shell";
  if (stage === 2) return kind === "game" ? "Code · blocking the world" : "Code · writing screens";
  if (stage === 3) return "Code · placing the hero";
  if (stage === 4) return kind === "game" ? "Code · wiring HUD" : "Code · wiring controls";
  return "Critic · ready for your test";
}

export function buildChips(input: {
  secrets: Secrets;
  health: Health;
  systemMapOn: boolean;
  selfHealOn: boolean;
  researchOn: boolean;
  job: Job | null;
  secretsHealthOn: boolean;
}): { disabled: boolean; chips: Chip[] } {
  if (!input.systemMapOn) return { disabled: true, chips: [] };
  const d = deriveChecks(input.secrets, input.health, input.secretsHealthOn);
  const job = input.job;
  const working = job?.status === "assembling" || job?.status === "exporting";
  const chips: Chip[] = [];

  const promptState: Chip["state"] = !job || job.status === "cancelled"
    ? "muted"
    : job.status === "error" && job.stage === 0
      ? "error"
      : working && job.stage <= 1
        ? "active"
        : job.stage >= 1
          ? "done"
          : "ready";
  chips.push({
    id: "prompt",
    label: "Prompt",
    state: promptState,
    reason: job?.prompt ? "" : "no prompt yet",
    caption: job?.prompt ? stageCaption(Math.max(job.stage, working ? 1 : 0), job.kind) : "waiting for a prompt",
  });

  if (input.secrets.keys.length === 0) {
    chips.push({
      id: "keys-missing",
      label: "No API key",
      state: "muted",
      reason: "add at least one key under Secrets",
      caption: "text departments blocked",
    });
  } else {
    for (const key of input.secrets.keys) {
      const model = key.model || key.provider;
      const active = working && job?.activeKeyId === key.id;
      const failed = job?.status === "error" && job.activeKeyId === key.id;
      const used = !!job && job.activeKeyId === key.id && (job.status === "testing" || job.status === "ready" || job.status === "exporting");
      chips.push({
        id: `key-${key.id}`,
        label: key.label.trim() || `${key.provider} ${model}`,
        state: failed ? "error" : active ? "active" : used ? "done" : "ready",
        reason: failed ? job?.error || "call failed" : key.tags.length ? key.tags.join(" · ") : "untagged · general purpose",
        caption: active
          ? `${key.provider} · ${model} · ${stageCaption(job?.stage ?? 1, job?.kind ?? "app")}`
          : `${key.provider} · ${model}`,
      });
    }
  }

  chips.push({
    id: "github",
    label: d.github === "ok" && d.githubUser ? `GitHub · ${d.githubUser}` : "GitHub",
    state: d.github === "ok" ? (job?.status === "exporting" ? "active" : job?.repoUrl ? "done" : "ready") : "muted",
    reason: d.github === "ok" ? "" : d.githubDetail,
    caption: d.github === "ok" ? (job?.status === "exporting" ? "GitHub bot · pushing export" : `connected · ${d.githubUser ?? "user"}`) : d.githubDetail,
  });

  chips.push({
    id: "studio-fb",
    label: "Studio Firebase",
    state: d.studio === "ok" || d.studio === "skipped" ? "ready" : "muted",
    reason: d.studio === "ok" || d.studio === "skipped" ? "" : d.studioDetail,
    caption: d.studio === "ok" ? "reachable · jobs only, no API keys" : d.studioDetail,
  });

  chips.push({
    id: "apps-fb",
    label: "Apps Firebase",
    state: d.apps === "ok" || d.apps === "skipped" ? "ready" : "muted",
    reason: d.apps === "ok" || d.apps === "skipped" ? "" : d.appsDetail,
    caption: d.apps === "ok" ? "saved for inject into exports" : d.appsDetail,
  });

  if (input.secrets.voiceKey.trim()) {
    chips.push({
      id: "voice",
      label: "Voice key",
      state: "ready",
      reason: "",
      caption: "stored · Live still uses this browser’s speech recognition",
    });
  }

  if (input.researchOn) {
    const on = working && !!job && job.stage <= 1;
    chips.push({
      id: "research",
      label: "Research bot",
      state: on ? "active" : "ready",
      reason: "",
      caption: on ? "Research · checking outside facts" : "on when the prompt needs facts",
    });
  }

  if (input.selfHealOn) {
    const active = !!job && job.status === "assembling" && job.healAttempts > 0;
    chips.push({
      id: "critic",
      label: "Critic",
      state: active ? "active" : job?.criticNote ? "done" : "ready",
      reason: "",
      caption: job?.fallbackNote || job?.criticNote || (job?.healAttempts ? `repair ${job.healAttempts}/3` : "stands by for bad output"),
    });
  }

  return { disabled: false, chips };
}

export function mapFooter(input: { job: Job | null; derived: Derived; exportingNeedsGithub: boolean }): string {
  const { job, derived } = input;
  if (job?.status === "error") return `blocked · ${job.error || "build error"}`;
  if (job?.status === "cancelled") return "idle · job cancelled";
  if (job?.demo && (job.status === "testing" || job.status === "assembling")) return `${Math.max(job.stage, 0)}/5 stages · demo only`;
  if (job && (job.status === "exporting" || job.status === "ready") && input.exportingNeedsGithub && derived.github !== "ok") {
    return "blocked · missing GitHub token";
  }
  if (job?.status === "exporting") return `${job.stage}/5 stages · exporting`;
  if (job?.status === "testing" || job?.status === "ready") return `${job.stage}/5 stages · team in sync`;
  if (job?.status === "assembling") return `${job.stage}/5 stages · team in sync`;
  if (derived.github === "empty") return "idle · GitHub token not set";
  return "idle · waiting for a prompt";
}
