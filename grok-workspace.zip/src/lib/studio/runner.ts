import { askModel, type AskOut } from "./ai-fn.ts";
import { parseCommand, type Command } from "./commands.ts";
import { buildProjectFiles, slugify } from "./export-plan.ts";
import { pingRtdb, pullStudioState, pushStudioState } from "./firebase.ts";
import { githubPoll, githubPush, githubWhoami } from "./github-fn.ts";
import { say } from "./i18n.ts";
import { orderKeys } from "./routing.ts";
import { matchProductSkills, pickEngine } from "./skills.ts";
import { buildSpecPrompt, localSketch, needsResearch, parseSpec, tightenSpec } from "./spec.ts";
import { statusBrief } from "./status-text.ts";
import { uid, useStudio } from "./store.ts";
import type { ApiKey, Job, Tab } from "./types.ts";

let epoch = 0;
let screen: { tab: Tab } = { tab: "copilot" };
let go: (tab: Tab, build?: string) => void = () => {};
let syncTimer: ReturnType<typeof setTimeout> | null = null;

export function registerNavigator(fn: (tab: Tab, build?: string) => void): void {
  go = fn;
}

export function setScreen(tab: Tab): void {
  screen = { tab };
}

function alive(my: number): boolean {
  return epoch === my;
}

function sleep(ms: number, my: number): Promise<boolean> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(alive(my)), ms);
  });
}

async function wiki(prompt: string): Promise<string> {
  try {
    const q = prompt.split(/\s+/).slice(0, 8).join(" ");
    const url = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=1&namespace=0&format=json&origin=*`;
    const res = await fetch(url);
    if (!res.ok) return "";
    const body = (await res.json()) as [string, string[], string[], string[]];
    const title = body[1]?.[0];
    const desc = body[2]?.[0];
    if (!title) return "";
    return `${title}: ${desc || ""}`.slice(0, 500);
  } catch {
    return "";
  }
}

async function callKey(key: ApiKey, system: string, user: string): Promise<AskOut> {
  return askModel({
    data: {
      provider: key.provider,
      apiKey: key.secret,
      model: key.model,
      baseUrl: key.baseUrl,
      system,
      user,
      maxTokens: 900,
    },
  });
}

async function callWithFallback(
  dept: "brain" | "code" | "fast" | "vision" | "reason",
  system: string,
  user: string,
  jobId: string | null,
): Promise<{ res: AskOut; key: ApiKey | null }> {
  const s = useStudio.getState();
  const keys = orderKeys(s.secrets.keys, dept);
  if (keys.length === 0) return { res: { ok: false, status: 0, error: "No API key" }, key: null };
  const heal = s.skillOn("self-heal") ? 3 : 1;
  const allowFallback = s.skillOn("rate-fallback");
  let attempts = 0;
  let index = 0;
  let last: AskOut = { ok: false, status: 0, error: "No attempt" };
  while (attempts < heal && index < keys.length) {
    attempts += 1;
    const key = keys[index];
    if (jobId) {
      s.patchJob(jobId, {
        activeKeyId: key.id,
        healAttempts: attempts,
        fallbackNote: index > 0 ? `Fallback · ${key.label} after the previous key failed` : null,
      });
    }
    last = await callKey(key, system, user);
    if (last.ok) return { res: last, key };
    const retryable = last.status === 429 || last.status === 402 || last.status >= 500 || last.status === 0;
    if (retryable && allowFallback && index < keys.length - 1) {
      index += 1;
      continue;
    }
    if (!s.skillOn("self-heal")) break;
  }
  return { res: last, key: keys[Math.min(index, keys.length - 1)] ?? null };
}

function blankJob(partial: Pick<Job, "id" | "prompt" | "title" | "kind" | "engine" | "matchedSkills" | "skippedSkills" | "demo">): Job {
  const now = Date.now();
  return {
    ...partial,
    status: "assembling",
    stage: 1,
    createdAt: now,
    updatedAt: now,
    spec: null,
    specHistory: [],
    apkState: "none",
    apkLink: null,
    apkDetail: "",
    adminLink: null,
    adminDetail: "",
    actionsUrl: null,
    repoUrl: null,
    error: null,
    healAttempts: 0,
    activeKeyId: null,
    fallbackNote: null,
    criticNote: null,
    visionNote: null,
    testLog: [],
    files: null,
    bannerOn: false,
    notification: "",
    vipNote: "",
    repoOwner: null,
    repoName: null,
  };
}

export async function startBuild(prompt: string): Promise<void> {
  const s = useStudio.getState();
  const text = prompt.trim();
  if (!text) {
    s.note("needPrompt");
    return;
  }
  if (!s.skillOn("assembly-stages")) {
    s.note("assemblyOff");
    return;
  }
  const decision = pickEngine(text, s.skills);
  if (decision.engine === "flutter" && !s.skillOn("flutter-path")) {
    s.note("pathOff", { path: "Flutter" });
    return;
  }
  if (decision.engine === "godot" && !s.skillOn("godot-path")) {
    s.note("pathOff", { path: "Godot 4" });
    return;
  }
  const keys = orderKeys(s.secrets.keys, "code");
  if (keys.length === 0) {
    s.note("needKeyBuild");
    return;
  }
  if (keys.length === 1) s.note("singleKey", { label: keys[0].label });
  const { matched, skipped } = matchProductSkills(text, s.skills);
  const job = blankJob({
    id: uid(),
    prompt: text,
    title: text.slice(0, 48),
    kind: decision.kind,
    engine: decision.engine,
    matchedSkills: matched,
    skippedSkills: skipped,
    demo: false,
  });
  job.criticNote = decision.note;
  s.upsertJob(job);
  s.setView("factory");
  go("build");
  s.note("started", { what: text.slice(0, 80) });
  const my = ++epoch;
  await runReal(job.id, my);
}

export async function startDemo(prompt: string): Promise<void> {
  const s = useStudio.getState();
  if (s.secrets.keys.length > 0) return;
  if (!s.skillOn("assembly-stages")) {
    s.note("assemblyOff");
    return;
  }
  const text = prompt.trim() || (s.lang === "hi" ? "बिना नाम का स्केच" : "Untitled sketch");
  const decision = pickEngine(text, s.skills);
  const engine = decision.engine === "godot" && s.skillOn("engine-picker") ? "godot" : "flutter";
  const job = blankJob({
    id: uid(),
    prompt: text,
    title: text.slice(0, 48),
    kind: decision.kind,
    engine,
    matchedSkills: [],
    skippedSkills: [{ id: "demo", reason: "demo never applies product skills as a real build" }],
    demo: true,
  });
  job.spec = localSketch(text, job.engine, job.kind);
  s.upsertJob(job);
  s.setView("factory");
  go("build");
  s.note("demoOn");
  const my = ++epoch;
  for (const stage of [1, 2, 3, 4, 5]) {
    if (!alive(my)) return;
    s.patchJob(job.id, { stage, status: "assembling" });
    const ok = await sleep(650, my);
    if (!ok) return;
  }
  if (!alive(my)) return;
  s.patchJob(job.id, { stage: 5, status: "testing" });
}

async function runReal(id: string, my: number): Promise<void> {
  const s = useStudio.getState();
  const job = s.jobs.find((j) => j.id === id);
  if (!job) return;
  let research = "";
  if (s.skillOn("research-bot") && needsResearch(job.prompt)) {
    research = await wiki(job.prompt);
    if (!alive(my)) return;
    if (research) s.patchJob(id, { criticNote: `Research · ${research.slice(0, 140)}` });
  }
  const specPrompt = buildSpecPrompt({
    prompt: job.prompt,
    engine: job.engine,
    kind: job.kind,
    expand: s.skillOn("prompt-expand"),
    research,
  });
  const { res, key } = await callWithFallback("code", specPrompt.system, specPrompt.user, id);
  if (!alive(my)) return;
  if (!res.ok) {
    s.patchJob(id, { status: "error", error: res.error, activeKeyId: key?.id ?? null });
    s.note("buildFailed", { error: res.error });
    return;
  }
  const parsed = parseSpec(res.text, job.engine, job.kind);
  if (!parsed) {
    s.patchJob(id, { status: "error", error: "Model did not return a usable spec", activeKeyId: key?.id ?? null });
    s.note("buildFailed", { error: "Model did not return a usable spec" });
    return;
  }
  const spec = tightenSpec(parsed, s.skillOn("prompt-expand"));
  s.patchJob(id, { spec, title: spec.title, stage: 1, activeKeyId: key?.id ?? null });
  await revealRest(id, my, 1);
}

export async function revealRest(id: string, my: number, fromStage: number): Promise<void> {
  const s = useStudio.getState();
  for (const stage of [2, 3, 4, 5]) {
    if (stage <= fromStage) continue;
    if (!alive(my)) return;
    if (!useStudio.getState().skillOn("assembly-stages")) {
      s.patchJob(id, { status: "error", error: "Assembly stages skill turned off" });
      s.note("assemblyOff");
      return;
    }
    s.patchJob(id, { stage, status: "assembling" });
    const ok = await sleep(700, my);
    if (!ok) return;
  }
  if (!alive(my)) return;
  let visionNote: string | null = null;
  if (useStudio.getState().skillOn("vision-qa")) {
    const keys = orderKeys(useStudio.getState().secrets.keys, "vision");
    const current = useStudio.getState().jobs.find((j) => j.id === id);
    if (keys.length === 0) visionNote = say(useStudio.getState().lang, "visionSkipped");
    else if (current?.spec) {
      const critique = await callWithFallback(
        "vision",
        "You are the vision critic. Reply in under 80 words. List concrete UX issues in the spec. Do not claim you saw pixels.",
        JSON.stringify(current.spec),
        id,
      );
      if (!alive(my)) return;
      visionNote = critique.res.ok ? critique.res.text.slice(0, 500) : `Vision QA failed · ${critique.res.error}`;
    }
  }
  if (!alive(my)) return;
  s.patchJob(id, { stage: 5, status: "testing", visionNote });
  s.note("testReady");
}

export function resumeAssembly(): void {
  const s = useStudio.getState();
  const job = s.activeJob();
  if (!job || job.status !== "assembling") return;
  if (job.demo) {
    const my = ++epoch;
    void (async () => {
      for (let stage = Math.max(job.stage, 1); stage <= 5; stage++) {
        if (!alive(my)) return;
        s.patchJob(job.id, { stage, status: "assembling" });
        const ok = await sleep(650, my);
        if (!ok) return;
      }
      if (alive(my)) s.patchJob(job.id, { stage: 5, status: "testing" });
    })();
    return;
  }
  if (!s.skillOn("job-survivor")) {
    s.note("survivorPaused");
    return;
  }
  const my = ++epoch;
  if (!job.spec) void runReal(job.id, my);
  else void revealRest(job.id, my, job.stage);
}

export function forceResume(): void {
  const s = useStudio.getState();
  const job = s.activeJob();
  if (!job || job.demo) return;
  if (job.status !== "assembling" && job.status !== "error") return;
  s.setView("factory");
  const my = ++epoch;
  if (!job.spec) void runReal(job.id, my);
  else {
    s.patchJob(job.id, { status: "assembling", error: null });
    void revealRest(job.id, my, job.stage >= 5 ? 4 : job.stage);
  }
}

export function cancelBuild(): void {
  epoch += 1;
  const s = useStudio.getState();
  const job = s.activeJob();
  if (!job) return;
  if (job.status === "cancelled" || job.status === "ready") return;
  s.patchJob(job.id, { status: "cancelled", stage: 0, error: null });
  s.note("cancelled");
}

export async function applyChange(text: string): Promise<void> {
  const s = useStudio.getState();
  const job = s.activeJob();
  const change = text.trim();
  if (!job || !job.spec || !change) return;
  if (job.demo) {
    s.note("demoOn");
    return;
  }
  if (job.status !== "testing" && job.status !== "ready") return;
  if (s.skillOn("checkpoint")) s.patchJob(job.id, { specHistory: [...job.specHistory, job.spec].slice(-3) });
  const { res } = await callWithFallback(
    "code",
    "Revise the JSON spec. Return ONLY JSON with title, tagline, screens [{name, blurb}], hero, controls.",
    `Current spec:\n${JSON.stringify(job.spec)}\n\nChange:\n${change}`,
    job.id,
  );
  if (!res.ok) {
    s.note("changeFailed", { error: res.error });
    return;
  }
  const parsed = parseSpec(res.text, job.engine, job.kind);
  if (!parsed) {
    s.note("changeFailed", { error: "Model did not return a usable spec" });
    return;
  }
  const spec = tightenSpec(parsed, s.skillOn("prompt-expand"));
  s.patchJob(job.id, { spec, title: spec.title, status: "testing", stage: 5 });
  s.note("changeApplied");
}

export function rollback(): void {
  const s = useStudio.getState();
  const job = s.activeJob();
  if (!job || !s.skillOn("checkpoint") || job.specHistory.length === 0) {
    s.note("noCheckpoint");
    return;
  }
  const history = [...job.specHistory];
  const prev = history.pop();
  if (!prev) return;
  s.patchJob(job.id, { spec: prev, specHistory: history, title: prev.title, status: "testing", stage: 5 });
  s.note("rolledBack");
}

export async function confirmExport(): Promise<void> {
  const s = useStudio.getState();
  const job = s.activeJob();
  if (!job || job.demo || job.stage < 5 || (job.status !== "testing" && job.status !== "ready")) {
    s.note("notReady");
    return;
  }
  if (job.engine === "flutter" && !s.skillOn("flutter-path")) {
    s.note("pathOff", { path: "Flutter" });
    return;
  }
  if (job.engine === "godot" && !s.skillOn("godot-path")) {
    s.note("pathOff", { path: "Godot 4" });
    return;
  }
  s.note("exportBegan");
  s.patchJob(job.id, { status: "exporting" });
  const inject = s.skillOn("apps-firebase");
  const localFiles = buildProjectFiles({
    job: { ...job, status: "exporting" },
    secrets: s.secrets,
    injectApps: inject,
    assetHint: s.skillOn("asset-hint"),
    forGithub: false,
  });
  const githubFiles = buildProjectFiles({
    job: { ...job, status: "exporting" },
    secrets: s.secrets,
    injectApps: inject,
    assetHint: s.skillOn("asset-hint"),
    forGithub: true,
  });
  let apkState: Job["apkState"] = "none";
  let apkDetail = "";
  let apkLink: string | null = null;
  let actionsUrl: string | null = null;
  let repoUrl: string | null = null;
  let repoOwner: string | null = null;
  let repoName: string | null = null;
  let error: string | null = null;

  if (inject && s.secrets.appsUrl.trim() && s.secrets.appsKey.trim()) s.note("appsInjected");
  else if (inject) s.note("appsMissing");
  else s.note("appsSkillOff");

  if (!s.skillOn("github-connect")) {
    s.note("githubSkillOff");
    apkState = "blocked-skill";
    apkDetail = say(s.lang, "githubSkillOff");
  } else if (!s.secrets.token1.trim() || s.health.github !== "ok") {
    s.note("noToken");
    apkState = "blocked-token";
    apkDetail = say(s.lang, "noToken");
  } else {
    const pushed = await githubPush({
      data: {
        token: s.secrets.token1.trim(),
        repoName: `sarfealam-${slugify(job.spec?.title || job.title)}-${job.id.slice(0, 4)}`,
        description: `Sarfealam export · ${job.engine}`,
        files: githubFiles,
      },
    });
    if (!pushed.ok) {
      apkState = "push-failed";
      apkDetail = pushed.error;
      error = pushed.error;
      s.note("pushFailed", { error: pushed.error });
    } else {
      repoUrl = pushed.repoUrl;
      actionsUrl = pushed.actionsUrl;
      repoOwner = pushed.owner;
      repoName = pushed.repo;
      apkState = "queued";
      apkDetail = say(s.lang, "queued");
      s.note("queued");
      if (s.skillOn("actions-poll")) {
        const polled = await pollOnce(s.secrets.token1.trim(), pushed.owner, pushed.repo);
        if (polled.apkLink) {
          apkLink = s.skillOn("publish-apk") ? polled.apkLink : null;
          apkState = s.skillOn("publish-apk") ? "artifact" : "blocked-skill";
          apkDetail = s.skillOn("publish-apk") ? polled.detail : say(s.lang, "apkSkillOff");
          actionsUrl = polled.actionsUrl ?? actionsUrl;
          if (s.skillOn("publish-apk")) s.note("artifact");
          else s.note("apkSkillOff");
        }
      } else s.note("pollOff");
    }
  }

  if (apkState === "queued" && !s.skillOn("publish-apk")) {
    apkState = "blocked-skill";
    apkDetail = say(s.lang, "apkSkillOff");
    s.note("apkSkillOff");
  }

  let adminLink: string | null = null;
  let adminDetail = "";
  if (s.skillOn("publish-admin") && typeof window !== "undefined") {
    const url = new URL(window.location.href);
    url.searchParams.set("tab", "admin");
    url.searchParams.set("build", job.id);
    adminLink = url.toString();
    adminDetail = say(s.lang, "adminPublished");
    s.note("adminPublished");
  } else {
    adminDetail = say(s.lang, "adminSkillOff");
    s.note("adminSkillOff");
  }

  s.patchJob(job.id, {
    status: "ready",
    files: localFiles,
    apkState,
    apkLink,
    apkDetail,
    adminLink,
    adminDetail,
    actionsUrl,
    repoUrl,
    repoOwner,
    repoName,
    error,
  });
}

async function pollOnce(
  token: string,
  owner: string,
  repo: string,
): Promise<{ apkLink: string | null; detail: string; actionsUrl: string | null }> {
  const res = await githubPoll({ data: { token, owner, repo } });
  if (!res.ok) return { apkLink: null, detail: res.error, actionsUrl: null };
  const artifact = res.artifacts.find((a) => /apk/i.test(a.name));
  const run = res.runs[0];
  if (artifact && run?.htmlUrl) {
    return { apkLink: run.htmlUrl, detail: `Artifact ${artifact.name} · run #${run.number}`, actionsUrl: run.htmlUrl };
  }
  if (run?.htmlUrl) return { apkLink: null, detail: `Actions ${run.status}`, actionsUrl: run.htmlUrl };
  return { apkLink: null, detail: "No Actions run yet", actionsUrl: `https://github.com/${owner}/${repo}/actions` };
}

export async function pollActive(): Promise<void> {
  const s = useStudio.getState();
  const job = s.activeJob();
  if (!job?.repoOwner || !job.repoName) return;
  if (!s.skillOn("actions-poll")) {
    s.note("pollOff");
    return;
  }
  if (!s.skillOn("github-connect") || !s.secrets.token1.trim()) {
    s.note("noToken");
    return;
  }
  const polled = await pollOnce(s.secrets.token1.trim(), job.repoOwner, job.repoName);
  if (polled.apkLink && s.skillOn("publish-apk")) {
    s.patchJob(job.id, { apkState: "artifact", apkLink: polled.apkLink, apkDetail: polled.detail, actionsUrl: polled.actionsUrl });
    s.note("artifact");
    return;
  }
  s.patchJob(job.id, {
    apkDetail: polled.detail,
    actionsUrl: polled.actionsUrl ?? job.actionsUrl,
    apkState: polled.apkLink && !s.skillOn("publish-apk") ? "blocked-skill" : job.apkState,
  });
}

export async function refreshHealth(): Promise<void> {
  const s = useStudio.getState();
  if (!s.skillOn("secrets-health")) {
    s.setHealth({
      github: s.secrets.token1.trim() ? "skipped" : "empty",
      githubDetail: s.secrets.token1.trim() ? "saved · secrets health off" : "",
      githubUser: null,
      studio: s.secrets.studioUrl.trim() ? "skipped" : "empty",
      studioDetail: "",
      apps: s.secrets.appsUrl.trim() ? "skipped" : "empty",
      appsDetail: "",
    });
    return;
  }
  if (s.secrets.token1.trim()) {
    s.setHealth({ github: "checking", githubDetail: "checking token" });
    try {
      const who = await githubWhoami({ data: { token: s.secrets.token1.trim() } });
      if (who.ok) s.setHealth({ github: "ok", githubUser: who.login, githubDetail: "token accepted" });
      else s.setHealth({ github: "bad", githubUser: null, githubDetail: who.error });
    } catch (err) {
      s.setHealth({
        github: "bad",
        githubUser: null,
        githubDetail: err instanceof Error ? err.message : "GitHub unreachable",
      });
    }
  } else s.setHealth({ github: "empty", githubUser: null, githubDetail: "missing GitHub token" });
  await checkFirebase("studio");
  await checkFirebase("apps");
  if (useStudio.getState().skillOn("studio-firebase") && useStudio.getState().health.studio === "ok") await pullRemote();
}

async function checkFirebase(which: "studio" | "apps"): Promise<void> {
  const s = useStudio.getState();
  const url = which === "studio" ? s.secrets.studioUrl : s.secrets.appsUrl;
  const key = which === "studio" ? s.secrets.studioKey : s.secrets.appsKey;
  if (!url.trim() || !key.trim()) {
    const detail = which === "studio" ? "missing Studio Firebase" : "missing Apps Firebase";
    s.setHealth(which === "studio" ? { studio: url.trim() || key.trim() ? "bad" : "empty", studioDetail: detail } : { apps: url.trim() || key.trim() ? "bad" : "empty", appsDetail: detail });
    return;
  }
  const ping = await pingRtdb(url, key);
  if (which === "studio") s.setHealth({ studio: ping.ok ? "ok" : "bad", studioDetail: ping.detail });
  else s.setHealth({ apps: ping.ok ? "ok" : "bad", appsDetail: ping.detail });
}

async function pullRemote(): Promise<void> {
  const s = useStudio.getState();
  const pulled = await pullStudioState(s.secrets.studioUrl, s.secrets.studioKey);
  if (!pulled.ok || !pulled.payload || !Array.isArray(pulled.payload.jobs)) return;
  const jobs = pulled.payload.jobs.filter((row): row is Job => !!row && typeof row === "object" && typeof (row as Job).id === "string");
  useStudio.getState().mergeRemoteJobs(jobs, pulled.payload.activeJobId, pulled.payload.lang);
}

export function scheduleSync(): void {
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(() => {
    void pushRemote();
  }, 800);
}

async function pushRemote(): Promise<void> {
  const s = useStudio.getState();
  if (!s.skillOn("studio-firebase") || s.health.studio !== "ok") return;
  const jobs = s.jobs.map((job) => ({ ...job, files: null }));
  await pushStudioState(s.secrets.studioUrl, s.secrets.studioKey, {
    updatedAt: Date.now(),
    lang: s.lang,
    activeJobId: s.activeJobId,
    jobs,
  });
}

export function ensureWelcome(): void {
  const s = useStudio.getState();
  if (s.messages.length > 0) return;
  s.pushMessage({ role: "copilot", text: say(s.lang, "welcome"), kind: "welcome" });
}

export function bootStudio(): () => void {
  ensureWelcome();
  void refreshHealth().then(() => resumeAssembly());
  const unsub = useStudio.subscribe((state, prev) => {
    if (state.jobs !== prev.jobs || state.lang !== prev.lang || state.activeJobId !== prev.activeJobId) scheduleSync();
  });
  return () => {
    epoch += 1;
    unsub();
  };
}

async function runCommand(cmd: Command): Promise<void> {
  const s = useStudio.getState();
  if (cmd.type === "help") {
    s.note("help");
    return;
  }
  if (cmd.type === "lang") {
    s.setLang(cmd.lang);
    return;
  }
  if (cmd.type === "status") {
    s.pushMessage({
      role: "copilot",
      text: statusBrief({
        lang: s.lang,
        tab: screen.tab,
        secrets: s.secrets,
        health: s.health,
        skills: s.skills,
        job: s.activeJob(),
        liveOn: s.liveOn,
      }),
    });
    return;
  }
  if (cmd.type === "home") {
    s.setView("home");
    go("build");
    s.note("opened", { tab: "home" });
    return;
  }
  if (cmd.type === "cancel") {
    cancelBuild();
    return;
  }
  if (cmd.type === "ok") {
    await confirmExport();
    return;
  }
  if (cmd.type === "nav") {
    if (cmd.tab === "build") s.setView(s.activeJob() && s.activeJob()?.status !== "cancelled" ? "factory" : "home");
    go(cmd.tab, cmd.tab === "admin" ? (s.activeJobId ?? "") : undefined);
    s.note("opened", { tab: cmd.tab });
    return;
  }
  if (!cmd.rest) {
    s.note("needPrompt");
    return;
  }
  await startBuild(cmd.rest);
}

export async function handleUtterance(text: string): Promise<void> {
  const s = useStudio.getState();
  const trimmed = text.trim();
  if (!trimmed) return;
  s.pushMessage({ role: "user", text: trimmed });
  const cmd = parseCommand(trimmed);
  if (cmd) {
    await runCommand(cmd);
    return;
  }
  const keys = orderKeys(s.secrets.keys, "brain");
  if (keys.length === 0) {
    s.pushMessage({ role: "copilot", text: `${say(s.lang, "needKeyChat")}\n${say(s.lang, "help")}` });
    return;
  }
  const context = s.skillOn("screen-aware")
    ? statusBrief({
        lang: s.lang,
        tab: screen.tab,
        secrets: s.secrets,
        health: s.health,
        skills: s.skills,
        job: s.activeJob(),
        liveOn: s.liveOn,
      })
    : "Screen awareness is off. Do not invent tab, stage, or secret state.";
  const langLine = s.lang === "hi" ? "Reply in Hindi." : "Reply in English.";
  const { res } = await callWithFallback(
    "brain",
    `You are the Sarfealam Auto-Studio co-pilot. ${langLine} Be brief. Never claim an APK or a connection that the context does not confirm. If a secret is missing, name it.`,
    `${context}\n\nUser:\n${trimmed}`,
    null,
  );
  s.pushMessage({
    role: "copilot",
    text: res.ok ? res.text.slice(0, 1200) : say(s.lang, "buildFailed", { error: res.error }),
  });
}

export function speakText(text: string): void {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text.slice(0, 400));
  utter.lang = useStudio.getState().lang === "hi" ? "hi-IN" : "en-US";
  window.speechSynthesis.speak(utter);
}
