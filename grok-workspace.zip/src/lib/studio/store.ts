import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { say, type SayKey } from "./i18n.ts";
import { defaultSkillMap, skillOn as skillEnabled } from "./skills.ts";
import {
  EMPTY_HEALTH,
  EMPTY_SECRETS,
  type ApiKey,
  type ChatMessage,
  type Health,
  type Job,
  type Lang,
} from "./types.ts";

export function uid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

type Studio = {
  lang: Lang;
  skills: Record<string, boolean>;
  secrets: typeof EMPTY_SECRETS;
  health: Health;
  jobs: Job[];
  activeJobId: string | null;
  view: "home" | "factory";
  messages: ChatMessage[];
  liveOn: boolean;
  hearing: string;
  setLang: (lang: Lang) => void;
  toggleSkill: (id: string, on: boolean) => void;
  skillOn: (id: string) => boolean;
  setHealth: (partial: Partial<Health>) => void;
  saveKey: (key: ApiKey) => void;
  deleteKey: (id: string) => void;
  saveTokens: (token1: string, token2: string) => void;
  saveVoice: (voiceKey: string) => void;
  saveStudioFb: (url: string, key: string) => void;
  saveAppsFb: (url: string, key: string) => void;
  setView: (view: "home" | "factory") => void;
  setLive: (on: boolean) => void;
  setHearing: (text: string) => void;
  pushMessage: (message: Omit<ChatMessage, "id" | "ts"> & { id?: string; ts?: number }) => void;
  note: (key: SayKey, vars?: Record<string, string>) => void;
  upsertJob: (job: Job) => void;
  patchJob: (id: string, partial: Partial<Job>) => void;
  focusJob: (id: string) => void;
  activeJob: () => Job | null;
  logTest: (line: string) => void;
  mergeRemoteJobs: (jobs: Job[], activeJobId: string | null, remoteLang?: Lang) => void;
};

function memoryStorage(): Storage {
  const bag = new Map<string, string>();
  return {
    get length() {
      return bag.size;
    },
    clear: () => bag.clear(),
    getItem: (k) => bag.get(k) ?? null,
    key: (i) => [...bag.keys()][i] ?? null,
    removeItem: (k) => bag.delete(k),
    setItem: (k, v) => bag.set(k, v),
  };
}

function capJobs(jobs: Job[]): Job[] {
  return jobs
    .slice()
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, 10)
    .map((job, index) => (index > 4 ? { ...job, files: null } : job));
}

export const useStudio = create<Studio>()(
  persist(
    (set, get) => ({
      lang: "en",
      skills: defaultSkillMap(),
      secrets: EMPTY_SECRETS,
      health: EMPTY_HEALTH,
      jobs: [],
      activeJobId: null,
      view: "home",
      messages: [],
      liveOn: false,
      hearing: "",
      setLang: (lang) => {
        const current = get();
        if (current.lang === lang) return;
        set({
          lang,
          messages: current.messages.map((m) => (m.kind === "welcome" ? { ...m, text: say(lang, "welcome") } : m)),
        });
        get().pushMessage({ role: "copilot", text: say(lang, "langSet"), kind: "note" });
      },
      toggleSkill: (id, on) => set((s) => ({ skills: { ...s.skills, [id]: on } })),
      skillOn: (id) => skillEnabled(get().skills, id),
      setHealth: (partial) => set((s) => ({ health: { ...s.health, ...partial } })),
      saveKey: (key) =>
        set((s) => {
          const exists = s.secrets.keys.some((k) => k.id === key.id);
          const keys = exists ? s.secrets.keys.map((k) => (k.id === key.id ? key : k)) : [...s.secrets.keys, key];
          return { secrets: { ...s.secrets, keys } };
        }),
      deleteKey: (id) =>
        set((s) => ({ secrets: { ...s.secrets, keys: s.secrets.keys.filter((k) => k.id !== id) } })),
      saveTokens: (token1, token2) =>
        set((s) => ({
          secrets: { ...s.secrets, token1: token1.trim(), token2: token2.trim() },
          health: { ...s.health, github: token1.trim() ? "checking" : "empty", githubUser: null, githubDetail: "" },
        })),
      saveVoice: (voiceKey) => set((s) => ({ secrets: { ...s.secrets, voiceKey: voiceKey.trim() } })),
      saveStudioFb: (url, key) =>
        set((s) => ({
          secrets: { ...s.secrets, studioUrl: url.trim(), studioKey: key.trim() },
          health: { ...s.health, studio: url.trim() && key.trim() ? "checking" : "empty", studioDetail: "" },
        })),
      saveAppsFb: (url, key) =>
        set((s) => ({
          secrets: { ...s.secrets, appsUrl: url.trim(), appsKey: key.trim() },
          health: { ...s.health, apps: url.trim() && key.trim() ? "checking" : "empty", appsDetail: "" },
        })),
      setView: (view) => set({ view }),
      setLive: (on) => set({ liveOn: on, hearing: on ? get().hearing : "" }),
      setHearing: (text) => set({ hearing: text }),
      pushMessage: (message) =>
        set((s) => ({
          messages: [
            ...s.messages,
            {
              role: message.role,
              text: message.text,
              kind: message.kind,
              id: message.id ?? uid(),
              ts: message.ts ?? Date.now(),
            },
          ].slice(-80),
        })),
      note: (key, vars) => {
        get().pushMessage({ role: "copilot", text: say(get().lang, key, vars), kind: "note" });
      },
      upsertJob: (job) =>
        set((s) => ({
          activeJobId: job.id,
          jobs: capJobs([job, ...s.jobs.filter((j) => j.id !== job.id)]),
        })),
      patchJob: (id, partial) =>
        set((s) => ({
          jobs: capJobs(s.jobs.map((j) => (j.id === id ? { ...j, ...partial, updatedAt: Date.now() } : j))),
        })),
      focusJob: (id) => {
        if (get().jobs.some((j) => j.id === id)) set({ activeJobId: id });
      },
      activeJob: () => get().jobs.find((j) => j.id === get().activeJobId) ?? null,
      logTest: (line) => {
        const job = get().activeJob();
        if (!job || job.status !== "testing") return;
        get().patchJob(job.id, { testLog: [...job.testLog, line].slice(-24) });
      },
      mergeRemoteJobs: (remoteJobs, activeJobId, remoteLang) => {
        const local = get().jobs;
        const byId = new Map(local.map((j) => [j.id, j]));
        for (const remote of remoteJobs) {
          if (!remote?.id) continue;
          const prev = byId.get(remote.id);
          if (!prev || remote.updatedAt > prev.updatedAt) {
            byId.set(remote.id, { ...remote, files: prev?.files ?? remote.files ?? null });
          }
        }
        set({
          jobs: capJobs([...byId.values()]),
          activeJobId: get().activeJobId || activeJobId,
          lang: remoteLang && get().messages.length <= 1 ? remoteLang : get().lang,
        });
      },
    }),
    {
      name: "sarfealam-studio-v1",
      storage: createJSONStorage(() => (typeof window === "undefined" ? memoryStorage() : localStorage)),
      skipHydration: true,
      partialize: (s) => ({
        lang: s.lang,
        skills: s.skills,
        secrets: s.secrets,
        jobs: s.jobs,
        activeJobId: s.activeJobId,
        view: s.view,
        messages: s.messages,
      }),
      version: 1,
    },
  ),
);
