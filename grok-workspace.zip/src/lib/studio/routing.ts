import type { ApiKey, Dept, Tag } from "./types.ts";

const PREFS: Record<Dept, Tag[]> = {
  brain: ["primary", "general"],
  code: ["code", "primary", "general"],
  fast: ["fast", "fallback", "general"],
  vision: ["vision"],
  reason: ["primary", "general", "code"],
};

function rank(key: ApiKey, dept: Dept): number {
  const prefs = PREFS[dept];
  for (let i = 0; i < prefs.length; i++) {
    if (key.tags.includes(prefs[i])) return i;
  }
  if (dept === "vision") return 100;
  if (key.tags.length === 0) return 40;
  if (key.tags.includes("fallback")) return 80;
  if (key.tags.length === 1 && key.tags[0] === "vision") return 90;
  return 50;
}

/** One saved key is enough for text departments. Vision stays tag-scoped unless it is the only key. */
export function orderKeys(keys: ApiKey[], dept: Dept): ApiKey[] {
  if (keys.length === 0) return [];
  if (keys.length === 1) return [keys[0]];
  return [...keys].filter((k) => rank(k, dept) < 100).sort((a, b) => rank(a, dept) - rank(b, dept));
}

export function providerDefaultModel(provider: ApiKey["provider"]): string {
  switch (provider) {
    case "gemini":
      return "gemini-2.0-flash";
    case "groq":
      return "llama-3.3-70b-versatile";
    case "openai":
      return "gpt-4o-mini";
    case "nvidia":
      return "meta/llama-3.1-70b-instruct";
    case "xai":
      return "grok-4.5";
    case "qwen":
      return "qwen-plus";
    case "anthropic":
      return "claude-3-5-haiku-latest";
    default:
      return "";
  }
}
