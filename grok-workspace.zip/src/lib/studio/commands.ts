import type { Tab } from "./types.ts";

export type Command =
  | { type: "build"; rest: string }
  | { type: "cancel" }
  | { type: "ok" }
  | { type: "home" }
  | { type: "status" }
  | { type: "help" }
  | { type: "lang"; lang: "en" | "hi" }
  | { type: "nav"; tab: Tab };

const BARE: Record<string, Tab> = {
  vault: "vault",
  वॉल्ट: "vault",
  admin: "admin",
  एडमिन: "admin",
  skills: "skills",
  skill: "skills",
  स्किल्स: "skills",
  स्किल: "skills",
  secrets: "secrets",
  secret: "secrets",
  सीक्रेट्स: "secrets",
  सीक्रेट: "secrets",
  copilot: "copilot",
  "co-pilot": "copilot",
  "को-पायलट": "copilot",
  कोपायलट: "copilot",
};

export function parseCommand(raw: string): Command | null {
  const text = raw.trim();
  if (!text) return null;
  const lower = text.toLowerCase();

  if (/^(help|मदद|commands|कमांड)$/i.test(text)) return { type: "help" };
  if (/^(hindi|हिंदी|हिन्दी)$/i.test(text) || /हिंदी में|switch to hindi/i.test(lower)) return { type: "lang", lang: "hi" };
  if (/^(english|angrezi|अंग्रेजी)$/i.test(text) || /switch to english|अंग्रेजी में/i.test(lower)) return { type: "lang", lang: "en" };
  if (/^(status|halat|हालत|स्थिति)$/i.test(text)) return { type: "status" };
  if (/^(home|ghar|घर|होम)$/i.test(text)) return { type: "home" };
  if (/^(ok|okay|theek|theek hai|ठीक|ठीक है|export|ship)$/i.test(text)) return { type: "ok" };
  if (/^(cancel|abort|रद्द|रुको|ruko|ruk|stop|band karo|बंद)$/i.test(text)) return { type: "cancel" };

  const open = text.match(/^(?:open|go to|show|kholo|खोलो)\s+(.+)$/i);
  if (open) {
    const piece = open[1].trim().toLowerCase();
    if (BARE[piece]) return { type: "nav", tab: BARE[piece] };
    if (/^build$|^बिल्ड$/.test(piece)) return { type: "nav", tab: "build" };
  }

  if (BARE[lower]) return { type: "nav", tab: BARE[lower] };

  const latin = text.match(/^(?:build|assemble|start(?:\s+build)?|banao|banavo|bana)\b[:\s-]*(.*)$/i);
  if (latin) return { type: "build", rest: (latin[1] ?? "").trim() };
  const hindi = text.match(/^(?:बनाओ|शुरू करो|शुरू)[:\s-]*(.*)$/);
  if (hindi) return { type: "build", rest: (hindi[1] ?? "").trim() };
  return null;
}
