import type { Job, ProjectFile, Secrets } from "./types.ts";

export function slugify(title: string): string {
  const s = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .replace(/^[0-9]+/, "")
    .slice(0, 28);
  return s || "sarfealam_app";
}

function has(job: Job, id: string): boolean {
  return job.matchedSkills.includes(id);
}

function dartString(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, " ");
}

function flutterMain(job: Job): string {
  const spec = job.spec;
  const title = dartString(spec?.title || job.title);
  const screens = spec?.screens?.length ? spec.screens : [{ name: "Home", blurb: job.prompt }];
  const names = screens.map((s) => dartString(s.name));
  const blurbs = screens.map((s) => dartString(s.blurb));
  const bottom = has(job, "bottom-nav") || names.length > 1;
  const wallet = has(job, "wallet");
  const search = has(job, "search");
  const vip = has(job, "vip");
  const otp = has(job, "otp-auth");
  const maps = has(job, "maps-booking");
  const cards = has(job, "card-table");
  const game = has(job, "game-controls") || job.kind === "game";
  const a11y = has(job, "a11y");
  const i18n = has(job, "i18n-strings");
  const ads = has(job, "ads-iap");
  return `import 'package:flutter/material.dart';

void main() => runApp(const GeneratedApp());

class GeneratedApp extends StatelessWidget {
  const GeneratedApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "${title}",
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF22D3EE), brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;
  bool signedIn = ${otp ? "false" : "true"};
  final screens = const [${names.map((n) => `"${n}"`).join(", ")}];
  final blurbs = const [${blurbs.map((n) => `"${n}"`).join(", ")}];

  @override
  Widget build(BuildContext context) {
    if (!signedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text("${title}")),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("OTP sign-in", style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text("Hook only. Wire Gmail or phone OTP to Apps Firebase in your project. This screen does not pretend a user is signed in."),
              const SizedBox(height: 16),
              ${a11y ? 'Semantics(label: "Continue to app", child: ' : ""}FilledButton(onPressed: () => setState(() => signedIn = true), child: const Text("Continue"))${a11y ? ")" : ""},
            ],
          ),
        ),
      );
    }
    final body = ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(screens[index], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(blurbs[index]),
        ${search ? 'const SizedBox(height: 12), TextField(decoration: InputDecoration(hintText: "Search")),' : ""}
        ${wallet ? 'const SizedBox(height: 12), Card(child: Padding(padding: EdgeInsets.all(16), child: Text("Balance · connect Apps Firebase before showing real money"))),' : ""}
        ${vip ? 'const SizedBox(height: 12), Text("VIP plan · locked until your own entitlement check"),' : ""}
        ${maps ? 'const SizedBox(height: 12), Container(height: 120, alignment: Alignment.center, color: Color(0xFF101826), child: Text("Booking layout · map SDK not bundled")),' : ""}
        ${cards ? 'const SizedBox(height: 12), Text("Card table · A♠  K♥  7♦  2♣"),' : ""}
        ${game ? `const SizedBox(height: 12),
          Wrap(spacing: 8, children: [
            OutlinedButton(onPressed: () {}, child: Text("Steer left")),
            OutlinedButton(onPressed: () {}, child: Text("Gas")),
            OutlinedButton(onPressed: () {}, child: Text("Brake")),
            OutlinedButton(onPressed: () {}, child: Text("Steer right")),
          ]),` : ""}
        ${ads ? 'const SizedBox(height: 12), Text("Ads / IAP hook · no network calls in this shell"),' : ""}
        ${i18n ? 'const SizedBox(height: 12), Text("EN · Home    HI · होम"),' : ""}
        const SizedBox(height: 12),
        Text("${dartString(spec?.hero || "")}"),
      ],
    );
    return Scaffold(
      appBar: AppBar(title: Text("${title}")),
      body: body,
      ${bottom ? `bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: [
          for (final name in screens) NavigationDestination(icon: const Icon(Icons.circle_outlined), label: name),
        ],
      ),` : ""}
    );
  }
}
`;
}

function flutterWorkflow(name: string): string {
  return `name: Android APK
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
        with:
          channel: stable
      - name: Preserve generated sources
        run: cp -a lib /tmp/lib-src && cp pubspec.yaml /tmp/pubspec.src.yaml
      - name: Create Android project files
        run: flutter create --org com.sarfealam --project-name ${name} .
      - name: Restore generated sources
        run: cp -a /tmp/lib-src/. lib/ && cp /tmp/pubspec.src.yaml pubspec.yaml
      - run: flutter pub get
      - run: flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: build/app/outputs/flutter-apk/app-release.apk
`;
}

function godotWorkflow(): string {
  return `name: Godot Android APK
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
jobs:
  apk:
    runs-on: ubuntu-latest
    container:
      image: barichello/godot-ci:4.3
    steps:
      - uses: actions/checkout@v4
      - name: Export release APK
        run: |
          mkdir -p build
          godot --headless --export-release "Android" build/game.apk
      - uses: actions/upload-artifact@v4
        with:
          name: game-apk
          path: build/game.apk
`;
}

function readme(job: Job, appsNote: string, assetHint: boolean): string {
  const skipped = job.skippedSkills.map((s) => `- ${s.id}: ${s.reason}`).join("\n") || "- none";
  const matched = job.matchedSkills.join(", ") || "none";
  return `# ${job.spec?.title || job.title}

Generated by Sarfealam Auto-Studio.

- Engine: ${job.engine === "godot" ? "Godot 4" : "Flutter"}
- Kind: ${job.kind}
- Prompt: ${job.prompt}

## Skills the engine applied
${matched}

## Skills asked by the prompt but not applied
${skipped}

## APK
GitHub Actions workflow: \`.github/workflows/android-apk.yml\`.
The studio shows an APK link only after Actions uploads an artifact. A queued run is not an APK.

${appsNote}

${assetHint ? "## Open-source asset hint\nLook at Kenney.nl (CC0) or Lucide for UI icons. This export did not download third-party assets.\n" : ""}
${job.matchedSkills.includes("offline-hint") ? "## Offline\nCache last-viewed records on device. Not implemented as a database in this shell.\n" : ""}
${job.matchedSkills.includes("perf-hint") ? "## Performance budget\nKeep first screen under a short build, avoid large uncompressed images, target a steady frame time on mid-range Android.\n" : ""}
${job.matchedSkills.includes("theme-variants") ? "## Themes\nDark is the default. A light ColorScheme can mirror the same seed color.\n" : ""}
`;
}

function firebaseFiles(secrets: Secrets, inject: boolean, forGithub: boolean): ProjectFile[] {
  const sample = JSON.stringify({ url: "", key: "", note: "Set GitHub Actions secrets APPS_FIREBASE_URL and APPS_FIREBASE_KEY. Do not commit the real key." }, null, 2);
  const files: ProjectFile[] = [{ path: "config/apps_firebase.sample.json", content: sample + "\n" }];
  if (inject && !forGithub) {
    files.push({
      path: "config/apps_firebase.json",
      content: JSON.stringify({ url: secrets.appsUrl.trim(), key: secrets.appsKey.trim() }, null, 2) + "\n",
    });
  }
  return files;
}

export function buildProjectFiles(input: {
  job: Job;
  secrets: Secrets;
  injectApps: boolean;
  assetHint: boolean;
  forGithub: boolean;
}): ProjectFile[] {
  const job = input.job;
  const name = slugify(job.spec?.title || job.title);
  const appsReady = !!(input.secrets.appsUrl.trim() && input.secrets.appsKey.trim());
  const inject = input.injectApps && appsReady;
  const appsNote = !input.injectApps
    ? "Apps Firebase inject skill is off. No Apps Firebase config was written."
    : inject
      ? input.forGithub
        ? "Apps Firebase URL/key are NOT in this Git tree. Add them as Actions secrets. The studio keeps them in the local package only."
        : "Apps Firebase config is in config/apps_firebase.json for this local package."
      : "Apps Firebase inject is on, but URL or key was empty, so nothing was injected.";
  const files: ProjectFile[] = [
    { path: "README.md", content: readme(job, appsNote, input.assetHint) },
    { path: ".gitignore", content: "build/\n.dart_tool/\nconfig/apps_firebase.json\n" },
  ];
  if (job.matchedSkills.includes("store-listing")) {
    files.push({
      path: "STORE_LISTING.md",
      content: `# ${job.spec?.title || job.title}\n\n${job.spec?.tagline || job.prompt}\n\nShort description:\n${(job.spec?.hero || job.prompt).slice(0, 80)}\n`,
    });
  }
  if (job.matchedSkills.includes("release-notes")) {
    files.push({
      path: "RELEASE_NOTES.md",
      content: `# 1.0.0\n\n- First export from Sarfealam Auto-Studio\n- Prompt: ${job.prompt}\n`,
    });
  }
  files.push(...firebaseFiles(input.secrets, inject, input.forGithub));

  if (job.engine === "godot") {
    const title = (job.spec?.title || job.title).replace(/"/g, "");
    files.push(
      {
        path: "project.godot",
        content: `; Engine configuration file.
config_version=5

[application]
config/name="${title}"
run/main_scene="res://scenes/main.tscn"
config/features=PackedStringArray("4.3")

[display]
window/size/viewport_width=720
window/size/viewport_height=1280
`,
      },
      {
        path: "export_presets.cfg",
        content: `[preset.0]
name="Android"
platform="Android"
runnable=true
export_filter="all_resources"
`,
      },
      {
        path: "scenes/main.tscn",
        content: `[gd_scene load_steps=2 format=3]

[ext_resource type="Script" path="res://scripts/main.gd" id="1"]

[node name="Main" type="Node2D"]
script = ExtResource("1")
`,
      },
      {
        path: "scripts/main.gd",
        content: `extends Node2D

var speed := 0.0
var heading := 0.0

func _ready() -> void:
    print("${title.replace(/"/g, "")}")

func steer(dir: float) -> void:
    heading += dir

func gas() -> void:
    speed = min(speed + 40.0, 240.0)

func brake() -> void:
    speed = max(speed - 80.0, 0.0)
`,
      },
      { path: ".github/workflows/android-apk.yml", content: godotWorkflow() },
    );
  } else {
    files.push(
      {
        path: "pubspec.yaml",
        content: `name: ${name}
description: Generated by Sarfealam Auto-Studio.
publish_to: "none"
version: 1.0.0+1
environment:
  sdk: ">=3.3.0 <4.0.0"
dependencies:
  flutter:
    sdk: flutter
flutter:
  uses-material-design: true
`,
      },
      { path: "lib/main.dart", content: flutterMain(job) },
      { path: ".github/workflows/android-apk.yml", content: flutterWorkflow(name) },
    );
  }
  return files;
}
