import assert from "node:assert/strict";
import test from "node:test";
import { parseCommand } from "./commands.ts";
import { buildProjectFiles } from "./export-plan.ts";
import { buildChips, deriveChecks, mapFooter } from "./map.ts";
import { orderKeys } from "./routing.ts";
import { buildSpecPrompt, parseSpec } from "./spec.ts";
import { matchProductSkills, pickEngine, skillOn } from "./skills.ts";
import { EMPTY_HEALTH, EMPTY_SECRETS, type Job, type Secrets } from "./types.ts";

const skillsOn = Object.fromEntries(
  ["prompt-match", "engine-picker", "wallet", "assembly-stages"].map((id) => [id, true]),
);

function job(partial: Partial<Job> = {}): Job {
  const now = Date.now();
  return {
    id: "job1",
    title: "Shop",
    prompt: "shop wallet app",
    kind: "app",
    engine: "flutter",
    status: "testing",
    stage: 5,
    matchedSkills: ["wallet"],
    skippedSkills: [],
    createdAt: now,
    updatedAt: now,
    spec: {
      title: "Shop",
      kind: "app",
      engine: "flutter",
      tagline: "Pay later",
      screens: [{ name: "Home", blurb: "Counter" }],
      hero: "Counter",
      controls: [],
      demo: false,
    },
    specHistory: [],
    apkState: "none",
    apkLink: null,
    apkDetail: "",
    adminLink: null,
    adminDetail: "",
    actionsUrl: null,
    repoUrl: null,
    error: null,
    healAttempts: 0,
    activeKeyId: null,
    fallbackNote: null,
    criticNote: null,
    visionNote: null,
    testLog: [],
    files: null,
    bannerOn: false,
    notification: "",
    vipNote: "",
    demo: false,
    repoOwner: null,
    repoName: null,
    ...partial,
  };
}

test("zero keys mute structural chips and do not claim APK", () => {
  const map = buildChips({
    secrets: EMPTY_SECRETS,
    health: EMPTY_HEALTH,
    systemMapOn: true,
    selfHealOn: true,
    researchOn: true,
    job: null,
    secretsHealthOn: true,
  });
  assert.equal(map.disabled, false);
  const github = map.chips.find((c) => c.id === "github");
  const missing = map.chips.find((c) => c.id === "keys-missing");
  assert.equal(github?.state, "muted");
  assert.match(github?.reason ?? "", /GitHub token/);
  assert.equal(missing?.state, "muted");
  assert.equal(map.chips.some((c) => c.caption.toLowerCase().includes("apk ready")), false);
  const footer = mapFooter({
    job: null,
    derived: deriveChecks(EMPTY_SECRETS, EMPTY_HEALTH, true),
    exportingNeedsGithub: false,
  });
  assert.match(footer, /missing GitHub token|GitHub token not set/);
});

test("a named key becomes a chip label", () => {
  const secrets: Secrets = {
    ...EMPTY_SECRETS,
    keys: [
      {
        id: "k1",
        label: "Qwen Coder",
        provider: "qwen",
        model: "qwen-plus",
        baseUrl: "",
        secret: "secret-value-123",
        tags: ["code"],
      },
    ],
  };
  const map = buildChips({
    secrets,
    health: EMPTY_HEALTH,
    systemMapOn: true,
    selfHealOn: false,
    researchOn: false,
    job: null,
    secretsHealthOn: true,
  });
  assert.ok(map.chips.some((c) => c.label === "Qwen Coder"));
});

test("one general key is used for code", () => {
  const only = [{ id: "k", label: "General", provider: "groq" as const, model: "m", baseUrl: "", secret: "x", tags: ["general" as const] }];
  assert.equal(orderKeys(only, "code")[0]?.label, "General");
});

test("wallet skill off is not applied", () => {
  const enabled = { ...skillsOn, wallet: false };
  const found = matchProductSkills("shop wallet app with balance", enabled);
  assert.equal(found.matched.includes("wallet"), false);
  assert.ok(found.skipped.some((s) => s.id === "wallet"));
});

test("engine picker chooses Godot for a racing game and Flutter when off", () => {
  assert.equal(pickEngine("build a 3D racing kart game", { "engine-picker": true }).engine, "godot");
  assert.equal(pickEngine("build a 3D racing kart game", { "engine-picker": false }).engine, "flutter");
});

test("commands drive cancel, ok, vault, and build", () => {
  assert.equal(parseCommand("cancel")?.type, "cancel");
  assert.equal(parseCommand("रद्द")?.type, "cancel");
  assert.equal(parseCommand("ok")?.type, "ok");
  assert.deepEqual(parseCommand("open vault"), { type: "nav", tab: "vault" });
  assert.equal(parseCommand("build a shop wallet")?.type, "build");
  const built = parseCommand("बनाओ दुकान ऐप");
  assert.equal(built?.type, "build");
});

test("apps firebase key is local-only", () => {
  const secrets: Secrets = { ...EMPTY_SECRETS, appsUrl: "https://demo-default-rtdb.firebaseio.com", appsKey: "super-secret-key" };
  const local = buildProjectFiles({ job: job(), secrets, injectApps: true, assetHint: false, forGithub: false });
  const remote = buildProjectFiles({ job: job(), secrets, injectApps: true, assetHint: false, forGithub: true });
  const localBody = local.map((f) => f.content).join("\n");
  const remoteBody = remote.map((f) => f.content).join("\n");
  assert.match(localBody, /super-secret-key/);
  assert.equal(remoteBody.includes("super-secret-key"), false);
  const off = buildProjectFiles({ job: job(), secrets, injectApps: false, assetHint: false, forGithub: false });
  assert.equal(off.map((f) => f.content).join("\n").includes("super-secret-key"), false);
});

test("system map skill off yields no chips", () => {
  const map = buildChips({
    secrets: EMPTY_SECRETS,
    health: EMPTY_HEALTH,
    systemMapOn: false,
    selfHealOn: true,
    researchOn: true,
    job: null,
    secretsHealthOn: true,
  });
  assert.equal(map.disabled, true);
  assert.equal(map.chips.length, 0);
});

test("prompt expand off keeps the instruction literal", () => {
  const off = buildSpecPrompt({ prompt: "list", engine: "flutter", kind: "app", expand: false, research: "" });
  assert.match(off.system, /Stay literal/);
  assert.equal(skillOn({ "prompt-expand": false }, "prompt-expand"), false);
});

test("spec parser rejects empty output", () => {
  assert.equal(parseSpec("not json", "flutter", "app"), null);
  const parsed = parseSpec('{"title":"Desk","tagline":"t","screens":[{"name":"Home","blurb":"b"}],"hero":"h","controls":["Tap"]}', "flutter", "app");
  assert.equal(parsed?.title, "Desk");
  assert.equal(parsed?.demo, false);
});
