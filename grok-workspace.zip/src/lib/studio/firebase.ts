export type StudioPayload = {
  updatedAt: number;
  lang: "en" | "hi";
  activeJobId: string | null;
  jobs: unknown[];
};

function endpoint(url: string, key: string, leaf: string): string {
  const base = url.trim().replace(/\/+$/, "");
  return `${base}/${leaf}.json?auth=${encodeURIComponent(key.trim())}`;
}

export function firebaseUrlOk(url: string): string | null {
  try {
    const u = new URL(url.trim());
    if (u.protocol !== "https:") return "URL must be https";
    if (!u.hostname.endsWith("firebaseio.com") && !u.hostname.includes("firebasedatabase")) {
      return "Use a Realtime Database URL (….firebaseio.com)";
    }
    return null;
  } catch {
    return "URL is not valid";
  }
}

export async function pingRtdb(url: string, key: string): Promise<{ ok: boolean; detail: string }> {
  const bad = firebaseUrlOk(url);
  if (bad) return { ok: false, detail: bad };
  if (!key.trim()) return { ok: false, detail: "missing key" };
  try {
    const res = await fetch(endpoint(url, key, "sarfealam/health"), {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ping: Date.now() }),
    });
    if (!res.ok) return { ok: false, detail: `HTTP ${res.status}` };
    return { ok: true, detail: "reachable" };
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : "network error" };
  }
}

export async function pushStudioState(
  url: string,
  key: string,
  payload: StudioPayload,
): Promise<{ ok: boolean; detail: string }> {
  const bad = firebaseUrlOk(url);
  if (bad) return { ok: false, detail: bad };
  try {
    const res = await fetch(endpoint(url, key, "sarfealam/state"), {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) return { ok: false, detail: `HTTP ${res.status}` };
    return { ok: true, detail: "synced" };
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : "network error" };
  }
}

export async function pullStudioState(
  url: string,
  key: string,
): Promise<{ ok: boolean; detail: string; payload: StudioPayload | null }> {
  const bad = firebaseUrlOk(url);
  if (bad) return { ok: false, detail: bad, payload: null };
  try {
    const res = await fetch(endpoint(url, key, "sarfealam/state"));
    if (!res.ok) return { ok: false, detail: `HTTP ${res.status}`, payload: null };
    const body = (await res.json()) as StudioPayload | null;
    if (!body || typeof body !== "object") return { ok: true, detail: "empty", payload: null };
    return { ok: true, detail: "pulled", payload: body };
  } catch (err) {
    return { ok: false, detail: err instanceof Error ? err.message : "network error", payload: null };
  }
}
