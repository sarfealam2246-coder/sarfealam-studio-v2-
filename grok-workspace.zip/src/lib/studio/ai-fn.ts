import { createServerFn } from "@tanstack/react-start";
import type { ProviderId } from "./types.ts";

type AskIn = {
  provider: ProviderId;
  apiKey: string;
  model: string;
  baseUrl: string;
  system: string;
  user: string;
  maxTokens: number;
};

export type AskOut =
  | { ok: true; text: string }
  | { ok: false; error: string; status: number };

function clip(text: string, key: string): string {
  return text.replaceAll(key, "•••").replace(/\s+/g, " ").slice(0, 180);
}

function assertHttps(raw: string): string {
  const u = new URL(raw);
  if (u.protocol !== "https:") throw new Error("Base URL must be https");
  const h = u.hostname.toLowerCase();
  if (
    h === "localhost" ||
    h.endsWith(".local") ||
    h === "metadata.google.internal" ||
    /^(127\.|10\.|192\.168\.|169\.254\.|0\.|\[::1\])/.test(h)
  ) {
    throw new Error("Base URL host is not allowed");
  }
  return u.toString().replace(/\/+$/, "");
}

async function readError(res: Response, key: string): Promise<string> {
  const text = await res.text();
  try {
    const body = JSON.parse(text) as { error?: { message?: string } | string };
    const msg = typeof body.error === "string" ? body.error : body.error?.message;
    if (msg) return clip(msg, key);
  } catch {
    /* raw text */
  }
  return clip(text || `HTTP ${res.status}`, key);
}

async function openAiCompatible(
  url: string,
  key: string,
  model: string,
  system: string,
  user: string,
  maxTokens: number,
): Promise<AskOut> {
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    signal: AbortSignal.timeout(28000),
    body: JSON.stringify({
      model,
      temperature: 0.3,
      max_tokens: maxTokens,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  if (!res.ok) return { ok: false, status: res.status, error: await readError(res, key) };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const text = body.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) return { ok: false, status: 502, error: "Empty model response" };
  return { ok: true, text };
}

async function gemini(key: string, model: string, system: string, user: string, maxTokens: number): Promise<AskOut> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    signal: AbortSignal.timeout(28000),
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents: [{ role: "user", parts: [{ text: user }] }],
      generationConfig: { maxOutputTokens: maxTokens, temperature: 0.3 },
    }),
  });
  if (!res.ok) return { ok: false, status: res.status, error: await readError(res, key) };
  const body = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
  const text = body.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  if (!text.trim()) return { ok: false, status: 502, error: "Empty model response" };
  return { ok: true, text };
}

async function anthropic(key: string, model: string, system: string, user: string, maxTokens: number): Promise<AskOut> {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    signal: AbortSignal.timeout(28000),
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });
  if (!res.ok) return { ok: false, status: res.status, error: await readError(res, key) };
  const body = (await res.json()) as { content?: { text?: string }[] };
  const text = body.content?.map((c) => c.text ?? "").join("") ?? "";
  if (!text.trim()) return { ok: false, status: 502, error: "Empty model response" };
  return { ok: true, text };
}

export const askModel = createServerFn({ method: "POST" })
  .validator((input: AskIn): AskIn => {
    if (!input || typeof input.apiKey !== "string" || input.apiKey.trim().length < 8) {
      throw new Error("API key missing");
    }
    if (typeof input.user !== "string" || !input.user.trim() || input.user.length > 12000) {
      throw new Error("Prompt missing or too long");
    }
    const maxTokens = Math.min(Math.max(input.maxTokens || 700, 64), 1200);
    return {
      provider: input.provider,
      apiKey: input.apiKey.trim(),
      model: (input.model || "").trim(),
      baseUrl: (input.baseUrl || "").trim(),
      system: (input.system || "").slice(0, 4000),
      user: input.user.slice(0, 12000),
      maxTokens,
    };
  })
  .handler(async ({ data }): Promise<AskOut> => {
    try {
      const model = data.model;
      if (!model && data.provider !== "custom") return { ok: false, status: 400, error: "Model name missing" };
      if (data.provider === "gemini") return await gemini(data.apiKey, model, data.system, data.user, data.maxTokens);
      if (data.provider === "anthropic") return await anthropic(data.apiKey, model, data.system, data.user, data.maxTokens);
      const endpoints: Record<string, string> = {
        groq: "https://api.groq.com/openai/v1/chat/completions",
        openai: "https://api.openai.com/v1/chat/completions",
        nvidia: "https://integrate.api.nvidia.com/v1/chat/completions",
        xai: "https://api.x.ai/v1/chat/completions",
        qwen: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1/chat/completions",
      };
      const url = data.provider === "custom" ? `${assertHttps(data.baseUrl)}/chat/completions` : endpoints[data.provider];
      if (!url) return { ok: false, status: 400, error: "Unknown provider" };
      if (!model) return { ok: false, status: 400, error: "Model name missing" };
      return await openAiCompatible(url, data.apiKey, model, data.system, data.user, data.maxTokens);
    } catch (err) {
      return { ok: false, status: 0, error: err instanceof Error ? err.message : "Request failed" };
    }
  });
