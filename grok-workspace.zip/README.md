# Sarfealam Auto-Studio

Control room for assembling an Android app or game, testing it on screen, and exporting a real project. The studio itself runs in the browser. The thing it exports is a Flutter app or a Godot 4 game, with a GitHub Actions workflow that can build an APK.

This is not a hollow demo shell. Skills, secrets, and job state change what the factory does. It will not say “connected” or “APK ready” unless a check or an Actions artifact actually says so.

## Two Firebases

| | Studio Firebase | Apps Firebase |
|---|---|---|
| Purpose | Studio records only: jobs, vault metadata, stage, language | Data backend for the generated app |
| When it is used | If the skill is on and the URL answers a Realtime Database ping | On OK, written into the **local** export package |
| What it must not hold | API keys and the GitHub token | Do not commit the key |

Use a Realtime Database URL such as `https://your-app-default-rtdb.firebaseio.com` plus the database secret. Rules must allow the studio’s REST client.

The GitHub push never contains `config/apps_firebase.json`. That file is gitignored and exists only in the zip you download. The workflow expects `APPS_FIREBASE_URL` and `APPS_FIREBASE_KEY` as Actions secrets if you want them in CI.

## Dynamic agent chips

Display B is not a fixed list of brands. Each saved API key becomes a chip named with the label you typed (`Qwen Coder`, `Gemini Flash`, …). GitHub, Studio Firebase, Apps Firebase, an optional voice slot, Research, and Critic appear from secrets and from skills that are on. A missing secret is a muted chip with a reason. A new key shows up after Save, and again after you reopen the studio.

One key is enough. It is routed through Brain and Code. Extra keys with tags (General, Code, Fast, Vision, Primary, Fallback) split departments. On HTTP 429 or 5xx, the rate-limit skill tries the next key and the map says so.

Vision QA runs only when that skill is on and a Vision-tagged key exists (a single saved key is also allowed, and the note says it is a text critique, not a pixel capture).

## Live vs the old voice loop

Live defaults to **off**. Turn it on and the studio listens like a call: “build a shop wallet”, “cancel”, “ok”, “vault”, “admin”, “skills”, “secrets”, “home”, “status”, “hindi”, “english”. It is not record → send → wait → TTS.

Typing stays available on Co-Pilot. Device voice on a message is optional playback. It does not replace Live. A separate voice key is only stored; Live uses the browser’s speech recognition.

The English | हिन्दी toggle sets co-pilot language, welcome text, and the main controls.

## Flutter vs Godot 4

The engine picker sends commercial / app prompts to Flutter and 3D or game prompts to Godot 4. Turning the picker off forces Flutter. Turning the Flutter path or the Godot path off blocks that export.

OK writes a project:

- Flutter: `pubspec.yaml`, `lib/main.dart`, `.github/workflows/android-apk.yml`. The workflow runs `flutter create` so the Android tree exists, restores the generated `lib/`, then `flutter build apk` and uploads `app-release-apk`.
- Godot 4: `project.godot`, scene, script, export preset, and a workflow on `barichello/godot-ci:4.3` that exports `game.apk`. The first Actions run can fail if presets or the debug keystore do not match that image. The studio still will not invent an APK link.

Product skills that are **on** and mentioned in the prompt change the preview and the generated sources (bottom nav, wallet, OTP hook, Hindi strings, store listing, and so on). A skill that is off is listed as not applied, even if the prompt asked for it.

## Where APK and Admin links show up

Flow: prompt → stages on Display A and the team map on Display B → test the on-screen controls → OK.

After OK:

- Vault and Admin show the **Admin** link for that build (this studio, that build) when the publish-admin skill is on.
- The **APK** slot stays empty, with a reason, until GitHub Actions has an artifact whose name contains `apk`. A queued run is linked as Actions, and the label says it is not an APK.
- With no GitHub token, or with the GitHub skill off, export still saves a source zip. Status says the APK is blocked. It does not say ready.
- With zero API keys, Assemble refuses. Demo walkthrough is labeled DEMO and cannot export.

Cancel aborts the job and resets stages. Home returns to the calm Build screen; a running job can be resumed. Jobs, secrets, language, skills, and the active build survive refresh in this browser. If Job survivor is off, a reload does not continue the assembly by itself.

## Put this project on GitHub for a real Actions APK

1. In Secrets, save a GitHub personal access token with the **repo** scope as Token1. Leave Token2 empty.
2. Save one model key so a real spec can be built.
3. Assemble, test, press OK. The studio creates a private repo and pushes the export.
4. Open the Actions link in Vault. When the artifact exists, press “Refresh Actions status”. The APK slot becomes the run that holds `app-release-apk` or `game-apk`.
5. Download that artifact from GitHub while signed in as the token’s user (private repos do not offer an anonymous APK file).

You can also download the source zip from Vault and push it yourself. Hollow pages with fake checkmarks are not an acceptable result for this studio: if a step did not happen, the map and the vault say why.
